package com.xsc.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    @NotNull(message = "id不能为空")
    private Long id;
    @NotEmpty(message = "姓名不能为空")
    @Length(min = 2, message = "姓名长度不能小于两位")
    private String name;
    @Min(value=16,message = "年龄必须大于16")
    private int age;

//    private static User user = new User(1L,"徐思成",24);  可以创建静态对象，也就是类对象
}
