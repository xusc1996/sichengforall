package com.xsc.controller;

import com.xsc.entity.Student;
import com.xsc.service.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/hello")
public class HelloHandler {

    @Autowired
    //虽然是注入是接口，但是这个接口并没有被实例化
    //new对象才是实例化的过程，这边只是直接引入
    private StudentRepository studentRepository; //注意：控制层注入的是接口而不是实现类，这里省去了一个业务层，本来注入的是业务层

    @GetMapping("/index")
    public ModelAndView index(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("index"); //转到指定的页面
        modelAndView.addObject("list",studentRepository.selectAll());//JSP中可以获取到这里存入的值
        return modelAndView;
    }

    @GetMapping("/SbyID/{sid}")
    public ModelAndView selectByID(@PathVariable("sid") long id){
        //你需要new一个对象哈哈，不需要在形参中去写这个参数
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("update");
        modelAndView.addObject("student",studentRepository.selectById(id));
        //跳转成功后我们将student对象放入其中，之前会调用方法赋值给student
        return modelAndView;
    }

    @GetMapping("/delete/{id}")
    public String deleteById(@PathVariable("id") long id){
        studentRepository.deleteById(id);
        //执行完成结果后发一个重定向
        return "redirect:/hello/index";
    }

    @PostMapping("/save")
    public String save(Student student){
        studentRepository.saveORupdate(student);
        return "redirect:/hello/index";
    }

    @PostMapping("/update")
    public String update(Student student){
        studentRepository.saveORupdate(student);
//        当我们执行修改操作，首先是index主页上点击那个修改
//        就会转到findById,从findByID才会转到update这个函数里
        return "redirect:/hello/index";
    }
}
