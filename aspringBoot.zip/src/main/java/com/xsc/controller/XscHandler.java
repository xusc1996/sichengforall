package com.xsc.controller;

import com.xsc.entity.Student;
import com.xsc.entity.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;


//这个Handler中我们已经不用JSP了，直接整合HTML
@Controller
@RequestMapping("/xsc")
public class XscHandler {

    @GetMapping("/index")
    public String xsc(Model model){
        System.out.println("index...");
        //后端向前端发送数据
        //我们还是可以运用视图解析器对象？Model
        List<Student> list = new ArrayList<>();
        list.add(new Student(3L,"徐思成",24));
        list.add(new Student(1L,"李薇",24));
        list.add(new Student(2L,"建成",26));
        model.addAttribute("list",list);
        return "index";
    }

    @GetMapping("/index2")
    public String xsc2(Map<String,String>map){
        map.put("name","张三");
        return "index";
    }

    @GetMapping("/if")
    public String xscif(Map<String,Boolean>map){
        map.put("flag",true);
        return "index";
    }

    @GetMapping("/test")
    public String test(Model model){
        //我们希望前端将Tom取出来并展示
        //我们url里输入了test之后，test里面会把url里空缺的名字自动转化为tom
        model.addAttribute("name","tom");
        return "test";
    }

    @GetMapping("/url/{name}")
    //加了这个之后直接返回在HTML页面上
    @ResponseBody
    public String url(@PathVariable("name") String name ){
        return name;
    }

    @GetMapping("/img")
    public String img(Model model){
        model.addAttribute("src","https://gimg2.baidu.com/image_search/src=http%3A%2F%2Falioss.gcores.com%2Fuploads%2Fimage%2Ffd59dc1d-c421-459f-a48d-3afac069aa99_watermark.jpg&refer=http%3A%2F%2Falioss.gcores.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1612441096&t=bc363c7773dfd890a3e08645d085bfa1");
        return "test";
    }

    @GetMapping("/eq")
    public String eq(Model model){
        model.addAttribute("age",30);
        return "test";
    }

    @GetMapping("/object")
    public String object(HttpServletRequest request){
        request.setAttribute("request","request对象");
        request.getSession().setAttribute("session","session对象");
        return "test";
    }

    @GetMapping("/util")
    public String util(Model model){
        model.addAttribute("name","张三");
        model.addAttribute("users",new ArrayList<>());
        model.addAttribute("count",22);
        model.addAttribute("date",new Date());
        return "test";
    }

    @GetMapping ("/sss")
    public String validatorUser(@Valid User user,BindingResult bindingResult,Model model){
        System.out.println(user);

        //这里的循环就是打印之前遇到的一些限制条件中不满足的
        if(bindingResult.hasErrors()){
            List<ObjectError> list = bindingResult.getAllErrors();
            for(ObjectError objectError : list){
                System.out.println(objectError.getCode()+"-"+objectError.getDefaultMessage());
            }
        }

        model.addAttribute("user",user);

        return "test";
    }

}
