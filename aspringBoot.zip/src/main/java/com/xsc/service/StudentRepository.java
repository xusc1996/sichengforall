package com.xsc.service;

import com.xsc.entity.Student;

import java.util.Collection;

public interface StudentRepository {
    public Collection<Student> selectAll();
    public Student selectById(long id);
    public void saveORupdate(Student student);
    public void deleteById(long id);
}
