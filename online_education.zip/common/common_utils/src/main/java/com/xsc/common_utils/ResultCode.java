package com.xsc.common_utils;

public interface ResultCode {

    //这里定义静态全局变量只能是公有的，普通变量也是
    //或者说接口中你没有办法定义私有变量
    public static Integer SUCCESS = 20000;

    public static Integer ERROR = 20001;

}
