package com.xsc.vodtest;

import com.aliyun.vod.upload.impl.UploadVideoImpl;
import com.aliyun.vod.upload.req.UploadVideoRequest;
import com.aliyun.vod.upload.resp.UploadVideoResponse;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.vod.model.v20170321.*;
import org.junit.Test;

import java.util.List;

public class testVod {

    @Test //本地上传文件的方法
    public void Upload() throws ClientException{

        String accessKeyId = "LTAI4FznwWSpdmmvpmbpJwnc";
        String accessKeySecret = "qMqpiw5ehQDLMBJNGkpuAvvfDI1pDf";

        //上传之后的文件名字
        String title = "1-Boston";
        //本地文件的路径和名字
        String fileName = "E:\\spring项目专用文件夹\\尚硅谷 在线教育平台\\1-阿里云上传测试视频\\6 - What If I Want to Move Faster.mp4";

        UploadVideoRequest request = new UploadVideoRequest(accessKeyId, accessKeySecret, title, fileName);

        /* 可指定分片上传时每个分片的大小，默认为2M字节 */
        request.setPartSize(2 * 1024 * 1024L);
        /* 可指定分片上传时的并发线程数，默认为1，(注：该配置会占用服务器CPU资源，需根据服务器情况指定）*/
        request.setTaskNum(1);

        UploadVideoImpl uploader = new UploadVideoImpl();
        UploadVideoResponse response = uploader.uploadVideo(request);

        if (response.isSuccess()) {
            System.out.print("VideoId=" + response.getVideoId() + "\n");
        } else {
            /* 如果设置回调URL无效，不影响视频上传，可以返回VideoId同时会返回错误码。其他情况上传失败时，VideoId为空，此时需要根据返回错误码分析具体错误原因 */
            System.out.print("VideoId=" + response.getVideoId() + "\n");

            //下面是上传出现问题的时候会显示的
            System.out.print("ErrorCode=" + response.getCode() + "\n");
            System.out.print("ErrorMessage=" + response.getMessage() + "\n");
        }
    }

    //根据视频ID获取视频 的播放地址
    @Test
    public void getAddress() throws ClientException {

        //        创建初始化对象
        DefaultAcsClient client = InitObject.initVodClient("LTAI4FznwWSpdmmvpmbpJwnc", "qMqpiw5ehQDLMBJNGkpuAvvfDI1pDf");

        //        创建获取视频地址request和response对象
        GetPlayInfoRequest request = new GetPlayInfoRequest();
        GetPlayInfoResponse response = new GetPlayInfoResponse();

        //        向request对象里面设置视频的id
        request.setVideoId("113158cd50c244ba8cbc94b6565aea7f");

        //        调用初始化对象里面的方法传递request,获取数据
        response = client.getAcsResponse(request);
        List<GetPlayInfoResponse.PlayInfo> playInfoList = response.getPlayInfoList();

        //播放地址
        for (GetPlayInfoResponse.PlayInfo playInfo : playInfoList) {
            System.out.print("PlayInfo.PlayURL = " + playInfo.getPlayURL() + "\n");
        }

        //Base信息       得到名字
        System.out.print("VideoBase.Title = " + response.getVideoBase().getTitle() + "\n");
    }

    @Test
    //根据视频id获取视频的播放凭证
    public void getPZ() throws ClientException {
        //        创建初始化对象
        DefaultAcsClient client = InitObject.initVodClient("LTAI4FznwWSpdmmvpmbpJwnc", "qMqpiw5ehQDLMBJNGkpuAvvfDI1pDf");

        //创建获取视频凭证的request和response
        GetVideoPlayAuthRequest request = new GetVideoPlayAuthRequest();
        GetVideoPlayAuthResponse response = new GetVideoPlayAuthResponse();

        //向request里面设置视频id值
        request.setVideoId("113158cd50c244ba8cbc94b6565aea7f");

        //调用初始化对象里面的request得到凭证
        response = client.getAcsResponse(request);
        System.out.println("playAuth:" + response.getPlayAuth());
    }
}
