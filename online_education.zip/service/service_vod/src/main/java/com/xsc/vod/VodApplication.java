package com.xsc.vod;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;

//我们这里并没有用到数据库，我们设置一下默认不加载数据库，否则报错
@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
//这行代码在所有的启动类上都加一下，因为要调用其他包里面的各种东西，设置一下扫描规则即可
@ComponentScan(basePackages = {"com.xsc"})
@EnableDiscoveryClient
public class VodApplication {
    public static void main(String[] args) {
        SpringApplication.run(VodApplication.class, args);
    }
}
