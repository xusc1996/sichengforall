package com.xsc.vod.Utils;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ConstantVodUtils implements InitializingBean {

    //注意这里写工具类赋值时不需要用el表达
    @Value("LTAI4FznwWSpdmmvpmbpJwnc")
    private String keyID;
    @Value("qMqpiw5ehQDLMBJNGkpuAvvfDI1pDf")
    private String keySecret;

    public static String KEY_ID;
    public static String KEY_SECRET;

    @Override
    public void afterPropertiesSet() throws Exception {
       KEY_ID = keyID;
       KEY_SECRET = keySecret;
    }
}
