package com.xsc.vod.controller;

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.vod.model.v20170321.DeleteVideoRequest;
import com.xsc.common_utils.R;
import com.xsc.servicebase.ExceptionHandler.LVexception;
import com.xsc.vod.Utils.ConstantVodUtils;
import com.xsc.vod.Utils.InitVod;
import com.xsc.vod.service.VodService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/eduVod/video")
@CrossOrigin
public class VodController {

    @Autowired
    private VodService vodService;

  //上传视频到阿里云的操作
    @PostMapping("uploadAliyunVideo")
    public R uploadAliyunVideo(MultipartFile file){
     //返回上传视频的ID值
      String videoId = vodService.uploadVideo(file);
      return R.ok().data("videoId",videoId);
  }

  //根据id删除视频
    @DeleteMapping("deleteAliyun/{id}")
    public R removeAlyVideo(@PathVariable String id){
        try{

            DefaultAcsClient client = InitVod.initVodClient(ConstantVodUtils.KEY_ID, ConstantVodUtils.KEY_SECRET);
            //创建删除视频的request对象
            DeleteVideoRequest request = new DeleteVideoRequest();
            //向request设置视频id
            request.setVideoIds(id);
            //调用初始化对象的方法
            client.getAcsResponse(request);
            return R.ok();

        }catch(Exception e){
            e.printStackTrace();
            throw new LVexception(20001,"删除视频失败");
        }
    }

    //删除多个阿里云中视频的方法，实现类中写需求的方法具体的
    @DeleteMapping("delete-batch")
    public R deleteBatch(@RequestParam("videoIdList") List<String> videoIdList){
        //我们只需要传入多个视频id即可,可以用String数组，也可以List集合
        vodService.removeVideoList(videoIdList);
        return R.ok();
    }

}
