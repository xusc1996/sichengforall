package com.xsc.excel;

import com.alibaba.excel.EasyExcel;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class TestEasyExcel {


    public static void main(String[] args) {
        //实现excel写的操作
        //设置写入的文件夹的地址和excel文件的名称
        String filename = "F:\\write.xlsx";

        //调用easyexcel里面的方法实现写操作
        //write方法中俩参数，文件路径和调用的实体类
        EasyExcel.write(filename,DemoData.class).sheet("学生列表").doWrite(getData());
    }

    //实现excel的读操作
    @Test
    public void testRead(){
        String filename = "F:\\write.xlsx";
        EasyExcel.read(filename,DemoData.class,new ExcelListener()).sheet().doRead();
    }

    //创建一个方法返回List集合
    private static List<DemoData> getData(){
        List<DemoData> list =  new ArrayList<>();
        for(int i = 0; i<10;i++){
            DemoData data = new DemoData();
            data.setSname("Lucy"+i);
            data.setSno(i);
            list.add(data);
        }
        return list;
    }
}
