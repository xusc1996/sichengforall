package com.xsc.serviceEdu.mapper;

import com.xsc.serviceEdu.entity.EduChapter;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 课程 Mapper 接口
 * </p>
 *
 * @author 老徐盖饭
 * @since 2021-01-19
 */
public interface EduChapterMapper extends BaseMapper<EduChapter> {

}
