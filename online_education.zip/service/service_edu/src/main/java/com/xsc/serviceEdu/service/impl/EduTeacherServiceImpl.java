package com.xsc.serviceEdu.service.impl;

import com.xsc.serviceEdu.entity.EduTeacher;
import com.xsc.serviceEdu.mapper.EduTeacherMapper;
import com.xsc.serviceEdu.service.EduTeacherService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 讲师 服务实现类
 * </p>
 *
 * @author 老徐盖饭
 * @since 2021-01-11
 */
@Service
public class EduTeacherServiceImpl extends ServiceImpl<EduTeacherMapper, EduTeacher> implements EduTeacherService {

}
