package com.xsc.serviceEdu.controller;


import com.xsc.common_utils.R;
import com.xsc.serviceEdu.entity.subject.OneSubject;
import com.xsc.serviceEdu.service.EduSubjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * <p>
 * 课程科目 前端控制器
 * </p>
 *
 * @author 老徐盖饭
 * @since 2021-01-18
 */
@RestController
@RequestMapping("/serviceEdu/subject")
@CrossOrigin  //记住每个controller里面都要加这个，为了跨域
public class EduSubjectController {

    @Autowired
    private EduSubjectService subjectService;

    //添加课程分类
    //获取到上传过来的文件，把文件中的内容读取出来
    @PostMapping("addSubject")
    public R addSubject(MultipartFile file){
        //得到上传过来的excel文件
        subjectService.saveSubject(file,subjectService);
        return R.ok();
    }


    //课程分类的列表功能
    //做到树形结构
    @GetMapping("/getAllSubject")
    public R getAllSubject(){
        //list集合泛型是一级分类
        List<OneSubject>list = subjectService.getAllOneTwoSubject(); //这个方法返回的是一级二级所有分类，封装好了
        return R.ok().data("list",list);
    }

}

