package com.xsc.serviceEdu.controller;

import com.xsc.common_utils.R;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/serviceEdu/user")
@CrossOrigin//解决跨域
public class EduLoginController {

    //login
    @PostMapping("login")
    public R login(){

        return R.ok().data("token","admin");
    }

    //info
    @GetMapping("info")
    public R info(){

        return R.ok().data("roles","[admin]").data("name","admin").data("avatar","https://gss0.baidu.com/9fo3dSag_xI4khGko9WTAnF6hhy/zhidao/pic/item/d009b3de9c82d158c6e3f2bc800a19d8bc3e425d.jpg");
    }
}
