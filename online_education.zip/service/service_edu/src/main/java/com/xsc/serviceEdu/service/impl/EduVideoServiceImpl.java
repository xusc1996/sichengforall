package com.xsc.serviceEdu.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.xsc.serviceEdu.client.VodClient;
import com.xsc.serviceEdu.entity.EduVideo;
import com.xsc.serviceEdu.mapper.EduVideoMapper;
import com.xsc.serviceEdu.service.EduVideoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.sql.Wrapper;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 课程视频 服务实现类
 * </p>
 *
 * @author 老徐盖饭
 * @since 2021-01-19
 */
@Service
public class EduVideoServiceImpl extends ServiceImpl<EduVideoMapper, EduVideo> implements EduVideoService {

    //删除章节的方法调用了这里，这里调用了vodClient中的方法
    //而vodClient中是调用的vod模块里的方法
    //这就是微服务架构
    @Autowired
    private VodClient vodClient;

    //注意这里是根据课程id删除小节，不能直接调用deleteById那样是根据小节id删除

    //当我们是自己调用自己的接口service时，可以用baseMapper，不然就得用wrapper来包装一下

    //删除的方法要选对，用delete来删
    @Override
    public void removeVideoByCourseId(String courseId) {
        //根据课程ID查询出课程里所有的视频ID
        QueryWrapper<EduVideo> wrapperVideo = new QueryWrapper<>();
        wrapperVideo.eq("course_id",courseId);
        //先只查找一个字段
        wrapperVideo.select("video_source_id");
        List<EduVideo> eduVideos = baseMapper.selectList(wrapperVideo);

        //这个方法要传递值，得是List<String>的形式而不是List<EduVideo>的形式，
        //得转换一下,通过遍历取和放
        List<String> videoIds = new ArrayList<>();
        for (int i = 0; i < eduVideos.size(); i++) {
            EduVideo eduVideo = eduVideos.get(i);
            String videoSourceId = eduVideo.getVideoSourceId();
            if(!StringUtils.isEmpty(videoSourceId)){
                //放到videoIds集合里面去
                videoIds.add(videoSourceId);
            }
        }

        if(videoIds.size()>0){
            //根据多个视频ID删除多个视频
            vodClient.deleteBatch(videoIds);
        }


        QueryWrapper<EduVideo> wrapper = new QueryWrapper<>();
        wrapper.eq("course_id",courseId);
        baseMapper.delete(wrapper);
    }
}
