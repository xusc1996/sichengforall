package com.xsc.serviceEdu.entity.chapter;

import lombok.Data;

@Data
public class VideoVO {

    private String id;
    private String title;
}
