package com.xsc.serviceEdu.service;

import com.xsc.serviceEdu.entity.EduChapter;
import com.baomidou.mybatisplus.extension.service.IService;
import com.xsc.serviceEdu.entity.chapter.ChapterVO;

import java.util.List;

/**
 * <p>
 * 课程 服务类
 * </p>
 *
 * @author 老徐盖饭
 * @since 2021-01-19
 */
public interface EduChapterService extends IService<EduChapter> {

    List<ChapterVO> getChapterVideoByCourseId(String courseId);

    boolean deleteChapter(String chapterId);

    void removeChapterByCourseId(String courseId);
}
