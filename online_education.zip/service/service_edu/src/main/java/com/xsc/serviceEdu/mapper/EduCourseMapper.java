package com.xsc.serviceEdu.mapper;

import com.xsc.serviceEdu.entity.EduCourse;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xsc.serviceEdu.entity.vo.CoursePublishVo;

/**
 * <p>
 * 课程 Mapper 接口
 * </p>
 *
 * @author 老徐盖饭
 * @since 2021-01-19
 */
public interface EduCourseMapper extends BaseMapper<EduCourse> {

    //好久没写mapper接口和xml语句了
    //我们首先是在mapper中定义方法，然后再到xml文件里面去写sql语句
    public CoursePublishVo getPublishCourseInfo(String courseId);


}
