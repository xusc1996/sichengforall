package com.xsc.serviceEdu.service;

import com.xsc.serviceEdu.entity.EduCourse;
import com.baomidou.mybatisplus.extension.service.IService;
import com.xsc.serviceEdu.entity.vo.CourseInfoVO;
import com.xsc.serviceEdu.entity.vo.CoursePublishVo;

/**
 * <p>
 * 课程 服务类
 * </p>
 *
 * @author 老徐盖饭
 * @since 2021-01-19
 */
public interface EduCourseService extends IService<EduCourse> {

    //我们让这个方法返回一下课程ID
    String saveCourseInfo(CourseInfoVO courseInfoVO);

    CourseInfoVO getCourseInfo(String courseId);

    void updateCourseInfo(CourseInfoVO courseInfoVO);

    CoursePublishVo publishCourseInfo(String id);

    void removeCourse(String courseId);
}
