package com.xsc.serviceEdu.controller;


import com.xsc.common_utils.R;
import com.xsc.serviceEdu.client.VodClient;
import com.xsc.serviceEdu.entity.EduVideo;
import com.xsc.serviceEdu.service.EduVideoService;
import com.xsc.servicebase.ExceptionHandler.LVexception;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 课程视频 前端控制器
 * </p>
 *
 * @author 老徐盖饭
 * @since 2021-01-19
 */
@RestController
@RequestMapping("/serviceEdu/video")
@CrossOrigin
public class EduVideoController {

    //注入VodClient
    @Autowired
    private VodClient vodClient;

    @Autowired
    private EduVideoService eduVideoService;

    //添加章节
    @GetMapping("getVideo/{id}")
    public R getVideo(@PathVariable String id){
        EduVideo video = eduVideoService.getById(id);
        return R.ok().data("video",video);
    }

    //添加小节
    @PostMapping("addVideo")
    public R addVideo(@RequestBody EduVideo eduVideo){
        eduVideoService.save(eduVideo);
        return R.ok();
    }
    //删除小节,一个小节里面只会用一个视频，因此我们这里调用的是client接口里的第一个方法
    //这个方法要完善，同时要把里面的视频删除
    @DeleteMapping("deleteVideo/{id}")
    public R deleteVideo(@PathVariable String id){
        //先根据小节id获取视频id,调用方法实现视频删除

        //通过videoId去获取video_source_id
        EduVideo eduVideo = eduVideoService.getById(id);
        String videoSourceId = eduVideo.getVideoSourceId();

        //注意顺序，先删除视频，再删除小节
        if(!StringUtils.isEmpty(videoSourceId)){
            //要做一个判断，因为我们的小节里面可能有视频，也可能没有的，因此要判断sourceId在不在
            R result = vodClient.removeAlyVideo(videoSourceId);
            if(result.getCode() == 20001){
                throw new LVexception(20001,"删除视频失败，熔断器....");
            }
        }

        //删除小节
        eduVideoService.removeById(id);
        return R.ok();
    }
    //修改小节
    @PostMapping("updateVideo")
    public R updateVideo(@RequestBody EduVideo eduVideo){
        eduVideoService.updateById(eduVideo);
        return R.ok();
    }
}

