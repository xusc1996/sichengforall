package com.xsc.serviceEdu.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.xsc.common_utils.R;
import com.xsc.serviceEdu.entity.EduCourse;
import com.xsc.serviceEdu.entity.vo.CourseInfoVO;
import com.xsc.serviceEdu.entity.vo.CoursePublishVo;
import com.xsc.serviceEdu.entity.vo.CourseQuery;
import com.xsc.serviceEdu.service.EduCourseService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 课程 前端控制器
 * </p>
 *
 * @author 老徐盖饭
 * @since 2021-01-19
 */
@RestController
@RequestMapping("/serviceEdu/course")
@CrossOrigin
public class EduCourseController {

    @Autowired
    private EduCourseService eduCourseService;

    //查询所有课程列表
    //too do 完善条件查询再分页

    //分页查询讲师方法
    @ApiOperation("分页查询课程")
    @GetMapping("pageCourse/{current}/{limit}")
    public R pageListTeacher(@PathVariable long current, @PathVariable long limit){

        //创建page对象
        Page<EduCourse> coursePage = new Page<>(current,limit);

        //调用方法实现分页
        //底层封装，所有数据会封装到teacherPage里面
        eduCourseService.page(coursePage,null);

        long total = coursePage.getTotal(); //总记录数
        List<EduCourse> records = coursePage.getRecords();//数据List集合

        return R.ok().data("total",total).data("rows",records);//这里records只会展示分页的一组数据
    }

    //条件查询课程，再分页的方式
    @ApiOperation("条件查询课程并分页")
    @PostMapping("/pageCourseCondition/{current}/{limit}")
    public R pageCourseCondition(@PathVariable long current, @PathVariable long limit,
                                  @RequestBody(required = false)CourseQuery courseQuery){

        //创建一个配置对象
        Page<EduCourse>eduCoursePage = new Page<>(current,limit);

        //构建条件wrapper
        QueryWrapper<EduCourse> wrapper = new QueryWrapper<>();


        //多条件查询有点类似mysql的动态拼接
        String title = courseQuery.getTitle();
        Integer status = courseQuery.getStatus();

        //判断这两个值是否等于空，若不为空，则拼接条件，这里写的都是表里的数据字段，而非实体类里的对象
        if(!StringUtils.isEmpty(title)){
            wrapper.like("title",title);
        }

        if (!StringUtils.isEmpty(status) ) {
            wrapper.eq("status", status);
        }

        //添加一下列表的排序,?????这里有些疑问啊，还能排序成功吗
        //用的是我们原始实体类的字段，还是修改后的query类里面的字段？
        //这里是根据原始实体类的字段
        wrapper.orderByDesc("gmt_create");


        //调用方法实现分页条件查询
        eduCourseService.page(eduCoursePage,wrapper);

        long total = eduCoursePage.getTotal(); //总记录数
        List<EduCourse> records = eduCoursePage.getRecords();//数据List集合records

        //注意前端很关注data信息里的名字，就是这样的rows
        return R.ok().data("total",total).data("rows",records);//这里records只会展示分页的一组数据
    }

    //首先写一个列出所有课程的方法,目前用这个显示在前端最基础
    @GetMapping
    public R getCourseList(){
        List<EduCourse> list = eduCourseService.list(null);
        return R.ok().data("list",list);
    }


    //添加课程基本信息的方法
    @PostMapping("/addCourseInfo")
    public R addCourseInfo(@RequestBody CourseInfoVO courseInfoVO) //传入一个VO类的对象
    {
        //返回添加之后的课程id，为了后面添加大纲时用
        String id = eduCourseService.saveCourseInfo(courseInfoVO);
        return R.ok().data("courseId",id);
    }


    //此步骤用于点击上一步时候的回显
    // 根据课程id查询课程的基本信息
    @GetMapping("getCourseInfo/{courseId}")
    public R getCourseInfo(@PathVariable String courseId){
       CourseInfoVO courseInfoVO = eduCourseService.getCourseInfo(courseId);
        return R.ok().data("courseInfoVo",courseInfoVO);
    }

    //修改课程信息
    @PostMapping("updateCourseInfo")
    public R updateCourseInfo(@RequestBody CourseInfoVO courseInfoVO){
        eduCourseService.updateCourseInfo(courseInfoVO);
        return R.ok();
    }

    //根据课程id查询确认信息并返回
    @GetMapping("getPublishCourseInfo/{id}")
    public R getPublishCourseInfo(@PathVariable String id){
        CoursePublishVo coursePublishVo = eduCourseService.publishCourseInfo(id);
        return R.ok().data("publish",coursePublishVo);
    }

    //课程最终发布
    //修改课程的状态,这个方法仅仅是去修改数据库里面的一个字段罢了
    @PostMapping("publishCourse/{id}")
    public R publishCourse(@PathVariable String id){
        EduCourse eduCourse = new EduCourse();
        eduCourse.setId(id);
        eduCourse.setStatus(1);  //设置课程的发布状态
        eduCourseService.updateById(eduCourse);
        return R.ok();
    }

    //删除课程，删除关联很多张表一起删除
    @DeleteMapping("deleteCourse/{courseId}")
    public R delete(@PathVariable String courseId){
        eduCourseService.removeCourse(courseId);
        return R.ok();
    }
}

