package com.xsc.serviceEdu.client;

import com.xsc.common_utils.R;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Component
//首先这里是你要调用的服务名称
@FeignClient(name = "service-vod",fallback = VodFileDegradeFeignClient.class)
public interface VodClient {

    //定义你要调用的方法路径
    //根据id删除视频,这里调用的话必须要写全路径，并且在pathVariable中加上你的id
    @DeleteMapping("/eduVod/video/deleteAliyun/{id}")
    public R removeAlyVideo(@PathVariable("id") String id);

    //定义删除多个视频的方法
    //我们在edu里面写一个接口，然后通过调用vod中的方法完成删除
    //在video中再注入这个client接口，来调用这里的方法
    //简单说来就是两次调用！
    @DeleteMapping("/eduVod/video/delete-batch")
    public R deleteBatch(@RequestParam("videoIdList") List<String> videoIdList);
}
