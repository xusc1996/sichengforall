package com.xsc.serviceEdu.service;

import com.xsc.serviceEdu.entity.EduTeacher;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 讲师 服务类
 * </p>
 *
 * @author 老徐盖饭
 * @since 2021-01-11
 */
public interface EduTeacherService extends IService<EduTeacher> {

}
