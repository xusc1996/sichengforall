package com.xsc.serviceEdu.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import com.xsc.common_utils.R;
import com.xsc.serviceEdu.entity.EduTeacher;
import com.xsc.serviceEdu.entity.vo.TeacherQuery;
import com.xsc.serviceEdu.service.EduTeacherService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 讲师 前端控制器
 * </p>
 *
 * @author 老徐盖饭
 * @since 2021-01-11
 */
@Api(description = "讲师管理")
@RestController
@RequestMapping("/serviceEdu/teacher")
@CrossOrigin
public class EduTeacherController {

    //controller层注入service层的对象!!!!!!
    @Autowired
    private EduTeacherService eduTeacherService;

    @ApiOperation("所有讲师列表")
    @GetMapping("/findAll")
    public R findAll(){
        List<EduTeacher> list = eduTeacherService.list(null);

//        try{
//            int i = 10/0;
//        }catch (Exception e){
//            //执行自定义异常,需要手动抛处
//            throw new LVexception(20001,"执行了自定义异常啊");
//        }

        return R.ok().data("items",list);
    }

    @ApiOperation("根据ID删除讲师，逻辑删除")
    @DeleteMapping("/deleteById/{id}")
    //这些api的注解相当于是中文翻译吧
    public R deleteById(@ApiParam(name = "id", value = "讲师ID", required = true)@PathVariable("id") String id){
        boolean b = eduTeacherService.removeById(id);
        if(b){
            return R.ok();
        }
        else {
            return R.error();
        }
    }


    //3.分页查询讲师方法
    @ApiOperation("分页查询讲师")
    @GetMapping("pageTeacher/{current}/{limit}")
    public R pageListTeacher(@PathVariable long current, @PathVariable long limit){

        //创建page对象
        Page<EduTeacher> teacherPage = new Page<>(current,limit);

        //调用方法实现分页
        //底层封装，所有数据会封装到teacherPage里面
        eduTeacherService.page(teacherPage,null);

        long total = teacherPage.getTotal(); //总记录数
        List<EduTeacher> records = teacherPage.getRecords();//数据List集合

        return R.ok().data("total",total).data("rows",records);//这里records只会展示分页的一组数据
    }

        //4.条件查询老师，再分页的方式
    @ApiOperation("条件查询老师并分页")
        @PostMapping("/pageTeacherCondition/{current}/{limit}")
        public R pageTeacherCondition(@PathVariable long current, @PathVariable long limit,
                                      @RequestBody(required = false) TeacherQuery teacherQuery){

            //创建一个配置对象
            Page<EduTeacher>teacherPage = new Page<>(current,limit);

            //构建条件wrapper
            QueryWrapper<EduTeacher>wrapper = new QueryWrapper<>();


            //多条件查询有点类似mysql的动态拼接
            String name = teacherQuery.getName();
            Integer level = teacherQuery.getLevel();
            String begin = teacherQuery.getBegin();
            String end = teacherQuery.getEnd();


            //判断这四个值是否等于空，若不为空，则拼接条件，这里写的都是表里的数据字段，而非实体类里的对象
            if(!StringUtils.isEmpty(name)){
              wrapper.like("name",name);
            }

            if (!StringUtils.isEmpty(level) ) {
                wrapper.eq("level", level);
            }

            //这里实际上是在写sql语句，所以要用表中的字段
            if (!StringUtils.isEmpty(begin)) {
                wrapper.ge("gmt_create", begin);//大于开始时间
            }

            if (!StringUtils.isEmpty(end)) {
                wrapper.le("gmt_create", end);//小于结束时间，对象都是导师的创建时间
            }

            //添加一下列表的排序
            wrapper.orderByDesc("gmt_create");


            //调用方法实现分页条件查询
            eduTeacherService.page(teacherPage,wrapper);

            long total = teacherPage.getTotal(); //总记录数
            List<EduTeacher> records = teacherPage.getRecords();//数据List集合records

           //注意前端很关注data信息里的名字，就是这样的rows
            return R.ok().data("total",total).data("rows",records);//这里records只会展示分页的一组数据
        }

        //5.添加讲师的接口方法
    @ApiOperation("添加一位老师")
    @PostMapping("addTeacher") //用了requestBody必须用post请求
    public R addTeacher(@RequestBody EduTeacher eduTeacher){

        boolean save = eduTeacherService.save(eduTeacher);

        if(save){
            return R.ok();
        }
        else{
            return R.error();
        }
    }
    //6.根据id查询讲师
    @ApiOperation("根据ID查询讲师")
    @GetMapping("getTeacherById/{id}")
    public R selectById(@PathVariable String id){
        EduTeacher res = eduTeacherService.getById(id);
        return R.ok().data("teacherById",res);
    }



    //7.讲师修改功能，可以对比一下下面的这种put提交的做法，简单一些
    @ApiOperation("修改导师信息")
    @PostMapping("updateTeacher")
    public R updateTeacher(@RequestBody EduTeacher eduTeacher){
        //这里根据id修改，传进去的是一个完整对象
        //我们测试的时候必须传入一个已经存在的ID值
        boolean b = eduTeacherService.updateById(eduTeacher);
        if(b){
            return R.ok();
        }
        else{
            return R.error();
        }
    }

//    @ApiOperation(value = "根据ID修改讲师")
//    @PutMapping("{id}")
//    public R updateById(
//            @ApiParam(name = "id", value = "讲师ID", required = true)
//            @PathVariable String id,
//
//            @ApiParam(name = "teacher", value = "讲师对象", required = true)
//            @RequestBody Teacher teacher){
//
//        teacher.setId(id);
//        teacherService.updateById(teacher);
//        return R.ok();
//    }

}

