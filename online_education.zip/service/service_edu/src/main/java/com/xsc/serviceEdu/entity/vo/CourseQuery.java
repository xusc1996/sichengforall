package com.xsc.serviceEdu.entity.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class CourseQuery implements Serializable { //这个接口是序列化接口，方便实体类的传输
    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "课程名称,模糊查询")
    private String title;

    @ApiModelProperty(value = "状态 Normal已经发布 Draft还未发布")
    private Integer status;
}
