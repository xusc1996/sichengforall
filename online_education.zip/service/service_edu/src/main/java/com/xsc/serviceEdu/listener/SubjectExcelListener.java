package com.xsc.serviceEdu.listener;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.xsc.serviceEdu.entity.EduSubject;
import com.xsc.serviceEdu.entity.excel.SubjectData;
import com.xsc.serviceEdu.service.EduSubjectService;
import com.xsc.servicebase.ExceptionHandler.LVexception;

public class SubjectExcelListener extends AnalysisEventListener<SubjectData> {
    //注意：listener需要自己去注入，不可以用Spring直接自动注入
    //监听器需要手动注入！！！

    //监听器你可以理解为第二个控制器controller,因此他也需要注入service层的对象才行
    public EduSubjectService subjectService;

    public SubjectExcelListener(EduSubjectService subjectService) {
        this.subjectService = subjectService;
    }

    public SubjectExcelListener(){

    }

    @Override
    public void invoke(SubjectData subjectData, AnalysisContext analysisContext) {
        if(subjectData == null){
            throw new LVexception(20001,"文件数据为空");
        }

        //判断一级分类是否重复
        EduSubject exsitOneSubject = this.exsitOneSubject(subjectService, subjectData.getOneSubjectName());
        if(exsitOneSubject == null){
            exsitOneSubject = new EduSubject();
            exsitOneSubject.setParentId("0");
            exsitOneSubject.setTitle(subjectData.getOneSubjectName());
            subjectService.save(exsitOneSubject);
        }

        //获取一级分类的ID值
        String pid = exsitOneSubject.getId();

        //判断二级分类是否重复
        EduSubject exsitTwoSubject = this.exsitTwoSubject(subjectService, subjectData.getTwoSubjectName(), pid);
        if(exsitTwoSubject == null){
            exsitTwoSubject = new EduSubject();
            exsitTwoSubject.setParentId(pid);
            exsitTwoSubject.setTitle(subjectData.getTwoSubjectName());
            subjectService.save(exsitTwoSubject);
        }
    }

    //判断一级分类不可重复添加
    private EduSubject exsitOneSubject(EduSubjectService subjectService, String name){
        QueryWrapper<EduSubject> wrapper = new QueryWrapper<>();
        wrapper.eq("title",name);
        wrapper.eq("parent_id","0");
        EduSubject one = subjectService.getOne(wrapper);
        return one;
    }

    //判断二级分类不可重复添加
    private EduSubject exsitTwoSubject(EduSubjectService subjectService, String name,String pid){
        QueryWrapper<EduSubject> wrapper = new QueryWrapper<>();
        wrapper.eq("title",name);
        wrapper.eq("parent_id",pid);
        EduSubject Two = subjectService.getOne(wrapper);
        return Two;
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {

    }
}
