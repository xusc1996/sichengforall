package com.xsc.serviceEdu.service.impl;

import com.xsc.common_utils.R;
import com.xsc.serviceEdu.entity.EduCourse;
import com.xsc.serviceEdu.entity.EduCourseDescription;
import com.xsc.serviceEdu.entity.vo.CourseInfoVO;
import com.xsc.serviceEdu.entity.vo.CoursePublishVo;
import com.xsc.serviceEdu.mapper.EduCourseMapper;
import com.xsc.serviceEdu.service.EduChapterService;
import com.xsc.serviceEdu.service.EduCourseDescriptionService;
import com.xsc.serviceEdu.service.EduCourseService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xsc.serviceEdu.service.EduVideoService;
import com.xsc.servicebase.ExceptionHandler.LVexception;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 课程 服务实现类
 * </p>
 *
 * @author 老徐盖饭
 * @since 2021-01-19
 */
@Service
public class EduCourseServiceImpl extends ServiceImpl<EduCourseMapper, EduCourse> implements EduCourseService {

    @Autowired
    private EduCourseDescriptionService eduCourseDescriptionService;

    //注入小节和章节的service
    @Autowired
    private EduVideoService eduVideoService;
    @Autowired
    private EduChapterService eduChapterService;

    //添加课程信息的方法
    @Override
    public String saveCourseInfo(CourseInfoVO courseInfoVO) {
        //向课程表里添加课程的基本信息
        //转换
        EduCourse eduCourse = new EduCourse();
        BeanUtils.copyProperties(courseInfoVO,eduCourse);
        //我们利用封装好的baseMapper做添加，但是要把传入进来的VO类转换为原来的实体类
        //baseMapper只能添加该实现类对应的实体类，因此不能添加描述信息进去，
        //描述信息要在EduServiceDescriptionImpl中实现
        int insert = baseMapper.insert(eduCourse);

        if(insert == 0){
            throw new LVexception(20001,"添加课程信息失败啦");
        }

        //获取成功之后的课程ID
        String cid = eduCourse.getId();

        //向课程的描述表里添加课程简介
        //新建实体类对象
        EduCourseDescription courseDescription = new EduCourseDescription();
        courseDescription.setDescription(courseInfoVO.getDescription());
        //业务层实现类调save方法来实现存入信息
        //手动设置一下描述ID就是课程ID,来让两张表中的信息能够保持联系
        courseDescription.setId(cid);
        eduCourseDescriptionService.save(courseDescription);

        //idea也太智能了吧。。。
        return cid;
    }

    @Override
    public CourseInfoVO getCourseInfo(String courseId) {
        //最终要将查询出来的将两个表数据封装到courseVo类中返回

        // 回显操作

        //查询课程表信息
        EduCourse eduCourse = baseMapper.selectById(courseId);
        CourseInfoVO courseInfoVO = new CourseInfoVO();
        BeanUtils.copyProperties(eduCourse,courseInfoVO);

        //查询课程描述表信息
        EduCourseDescription eduCourseDescription = eduCourseDescriptionService.getById(courseId);
        courseInfoVO.setDescription(eduCourseDescription.getDescription());

        return courseInfoVO;
    }

    //修改信息需要修改两张表
    @Override
    public void updateCourseInfo(CourseInfoVO courseInfoVO) {
        //先去修改课程表
        EduCourse eduCourse = new EduCourse();
        BeanUtils.copyProperties(courseInfoVO,eduCourse);

        //我们将修改后的值是放入了updateById方法中，
        //传入的还是一个对象,这个里面本身就是要放入新的对象
        int i = baseMapper.updateById(eduCourse);

        if(i == 0){
            throw new LVexception(20001,"修改失败啦");
        }

        //修改描述表信息
        EduCourseDescription description = new EduCourseDescription();
        description.setId(courseInfoVO.getId());
        description.setDescription(courseInfoVO.getDescription());

        eduCourseDescriptionService.updateById(description);
    }

    @Override
    public CoursePublishVo publishCourseInfo(String id) {
        //调用自己写的mapper，必须要用baseMapper来完成
        CoursePublishVo publishCourseInfo = baseMapper.getPublishCourseInfo(id);

        return publishCourseInfo;
    }

    //list页面删除课程的接口，要将四个表中的不同字段都删除掉
    @Override
    public void removeCourse(String courseId) {
        //根据课程id先去删除课程里的小节，这里调用了video里的方法
        eduVideoService.removeVideoByCourseId(courseId);
        //根据课程id删除章节
        eduChapterService.removeChapterByCourseId(courseId);
        //根据课程id删除课程描述,描述id和课程id是同一个id可以直接调用框架帮我们封装的对象
        eduCourseDescriptionService.removeById(courseId);
        //删除课程本身
        int result = baseMapper.deleteById(courseId);

        if(result == 0){
            throw new LVexception(20001,"删除失败");
        }
    }
}
