package com.xsc.serviceEdu.client;

import com.xsc.common_utils.R;
import org.springframework.stereotype.Component;

import java.util.List;

@Component  //切记先交给spring 管理！！！！！
public class VodFileDegradeFeignClient implements VodClient{

    //我们这里重写两个方法，如果之前的方法出错才会执行，但如果之前的方法正常就不会执行下列方法

    @Override
    public R removeAlyVideo(String id) {
        return R.error().message("删除视频出错了");
    }

    @Override
    public R deleteBatch(List<String> videoIdList) {
        return R.error().message("删除多个视频出错了");
    }
}
