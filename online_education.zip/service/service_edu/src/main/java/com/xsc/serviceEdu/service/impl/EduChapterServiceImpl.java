package com.xsc.serviceEdu.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.xsc.serviceEdu.entity.EduChapter;
import com.xsc.serviceEdu.entity.EduVideo;
import com.xsc.serviceEdu.entity.chapter.ChapterVO;
import com.xsc.serviceEdu.entity.chapter.VideoVO;
import com.xsc.serviceEdu.mapper.EduChapterMapper;
import com.xsc.serviceEdu.service.EduChapterService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xsc.serviceEdu.service.EduVideoService;
import com.xsc.servicebase.ExceptionHandler.LVexception;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 课程 服务实现类
 * </p>
 *
 * @author 老徐盖饭
 * @since 2021-01-19
 */
@Service
public class EduChapterServiceImpl extends ServiceImpl<EduChapterMapper, EduChapter> implements EduChapterService {

    @Autowired
    private EduVideoService eduVideoService;

    @Override
    public List<ChapterVO> getChapterVideoByCourseId(String courseId) {

        //根据课程id查询出所有的章节
        QueryWrapper<EduChapter>wrapperChapter = new QueryWrapper<>();
        wrapperChapter.eq("course_id",courseId);
        //我们是根据前端点击的课程ID，然后查到的是所有章节的集合
        List<EduChapter> eduChapters = baseMapper.selectList(wrapperChapter);

        //根据课程id查询出所有的小节
        QueryWrapper<EduVideo>wrapperVideo = new QueryWrapper<>();
        wrapperVideo.eq("course_id",courseId);
        List<EduVideo> eduVideos = eduVideoService.list(wrapperVideo);

        //创建一个list集合，用于最终封装数据
        List<ChapterVO> finalList = new ArrayList<>();

        //遍历章节list集合进行封装
        for (int i = 0; i < eduChapters.size(); i++) {
            //每个章节
            EduChapter eduChapter = eduChapters.get(i);
            //把eduChapter对象值复制到ChapterVO类型的里面去
            ChapterVO chapterVO = new ChapterVO();
            BeanUtils.copyProperties(eduChapter,chapterVO);
            finalList.add(chapterVO);

            //创建集合，用于封装章节的小节
            List<VideoVO> videoVOSfinal = new ArrayList<>();
            for (int i1 = 0; i1 < eduVideos.size(); i1++) {
                EduVideo eduVideo = eduVideos.get(i1);
                //需要判断小节里面的chapterId和章节里面的Id是否一样
                if(eduVideo.getChapterId().equals(eduChapter.getId())){
                    //如果相等，立即封装
                    VideoVO videoVO = new VideoVO();
                    BeanUtils.copyProperties(eduVideo,videoVO);
                    videoVOSfinal.add(videoVO);
                }
            }
            chapterVO.setChildren(videoVOSfinal);
        }

        //遍历小节list集合进行封装
        return finalList;
    }

    //删除章节的方法
    @Override
    public boolean deleteChapter(String chapterId) {
        //根据章节id查询小节表，如果能查询出数据，不进行删除
        QueryWrapper<EduVideo> wrapper = new QueryWrapper<>();
        wrapper.eq("chapter_id",chapterId);
        int count = eduVideoService.count(wrapper);

        if(count > 0){
            //查询出有小节，不进行删除
            throw new LVexception(20001,"不能删除啊");
        }else{
            int result = baseMapper.deleteById(chapterId);
            return result>0;
        }
    }

    @Override
    public void removeChapterByCourseId(String courseId) {
        QueryWrapper<EduChapter> wrapper = new QueryWrapper<>();
        wrapper.eq("course_id",courseId);
        baseMapper.delete(wrapper);
    }
}
