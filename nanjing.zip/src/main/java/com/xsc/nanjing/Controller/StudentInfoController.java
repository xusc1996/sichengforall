package com.xsc.nanjing.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("stuInfo")
public class StudentInfoController {

    @RequestMapping("/list")
    public String list(){
        return "stuInfo/list";
    }
}
