package com.xsc.nanjing.Controller;

import com.xsc.nanjing.model.CURDResult;
import com.xsc.nanjing.model.CourseOrder;
import com.xsc.nanjing.model.PageResult;
import com.xsc.nanjing.service.ICourseOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/courseOrder")
public class CourseOrderController {

    //永远记住注入的是接口，而不是实现类
    @Autowired
    ICourseOrderService courseOrderService;

    @RequestMapping("/list")
    public String list(){
        return "courseOrder/list";
    }

    @RequestMapping("listJson")
    @ResponseBody  //我们也可以直接这么写注释，返回一个json对象
    public PageResult<CourseOrder> listJson(int page, int limit){
                                                                 //感觉lay-ui分页还是很简单的，因为只需要一个条件+传递两个参数
        PageResult<CourseOrder> result = courseOrderService.findPageResult(null,page,limit);

        return result;
    }


    @RequestMapping("add")
    public String add(){
        return "courseOrder/add";
    }

    @RequestMapping("detail")  //接受list页面传过来的order_id
    public String detail(Model model,String order_id){
        CourseOrder order = courseOrderService.findByOrderId(order_id);
        model.addAttribute("order",order);
        return "courseOrder/detail";
    }

    @RequestMapping("delete")  //接受list页面传过来的order_id
    @ResponseBody //你不加这个你就接受不到JSON数据
    public CURDResult delete(String order_id){
        CURDResult result = new CURDResult();
        courseOrderService.deleteByOrderId(order_id);
        return result;
    }

    @RequestMapping("save")
    @ResponseBody          //前端用的是Jquery发送给我，这里用JSON数据格式接受一下
    public CURDResult save(CourseOrder courseOrder){
        CURDResult result = new CURDResult();

        //记住save总是一分为2的，调用同一个方法就简单
        //记住判断是否有ID用这个方法比较好！！！！
        if (StringUtils.isEmpty(courseOrder.getOrder_id())){
           //如果没有拿到id则需要插入数据
            System.out.println("正在插入");
            courseOrderService.save(courseOrder);
        }else{
            System.out.println("正在修改");
            courseOrderService.update(courseOrder);
        }

       return result;
    }

    @RequestMapping("edit")
    public String edit(Model model, String order_id){
        //这里还是和展示页面一样先取到这个id,只不过这边可编辑，detail那里不可编辑
        CourseOrder order = courseOrderService.findByOrderId(order_id);
        model.addAttribute("order",order);//注意这里不要乱存

        return "courseOrder/edit";
    }
}
