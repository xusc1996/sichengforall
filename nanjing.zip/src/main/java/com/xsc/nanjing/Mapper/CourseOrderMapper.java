package com.xsc.nanjing.Mapper;

import com.xsc.nanjing.model.CourseOrder;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface CourseOrderMapper {

    //在dao层我们添加俩方法
    public int findCountByMap(Map<String,Object> map);

    public List<CourseOrder>findListByMap(Map<String,Object> map);




    void insert(CourseOrder order);

    public CourseOrder findByOrder(String order_id);

    void deleteById(String order_id);

    void updateById(CourseOrder courseOrder);
}
