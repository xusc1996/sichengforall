package com.xsc.nanjing.model;

import lombok.Data;

import java.util.List;

@Data
//实际上这里还是写个封装类，统一返回结果
public class PageResult<T> {
    //0:success  1:error  消息码
    private int code;
    //错误信息
    private String msg;
    //总记录数
    private int count;
    //数据多行,我们可以把这个返回结果弄成通用，所以这里搞一个泛型
    private List<T> data;

}
