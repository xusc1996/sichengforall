package com.xsc.nanjing.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CURDResult {
    private int success =  1; //可以把默认值设置为1，成功
    private String msg = "";
}
