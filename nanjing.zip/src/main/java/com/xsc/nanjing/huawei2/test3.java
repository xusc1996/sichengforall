package com.xsc.nanjing.huawei2;

import java.util.Arrays;
import java.util.Scanner;

//做一个简单的题
//根据ASC码从大到小排列
public class test3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while(scanner.hasNext()){
            String str = scanner.nextLine();
            char[]chars = str.toCharArray();
            //记住这个库函数用来排序一个数组
            Arrays.sort(chars);
            System.out.println(chars);
        }
        scanner.close();
    }
}
