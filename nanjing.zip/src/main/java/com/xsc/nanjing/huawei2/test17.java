package com.xsc.nanjing.huawei2;

import java.util.Scanner;

public class test17 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while(sc.hasNext()){
            String str = sc.nextLine();
            char[] chars = str.toCharArray();

            //这个数组用来统计出现字符的数量
            int[]tmp = new int[128];
            for(int i = 0; i<chars.length; i++){
                tmp[chars[i]]++;
            }

            int max = 0;
            for(int i = 0; i<tmp.length; i++){
                if(tmp[i]>max){
                    //遍历一下整个数组找到出现最多的次数
                    max = tmp[i];
                }
            }

            StringBuffer sb = new StringBuffer();

            //max每循环一次-1，最终会变成0
            while (max != 0){
                for(int i = 0; i<tmp.length; i++){
                    if(tmp[i] == max){
                        //我们从前往后遍历。保证了出现次数相同的时候。阿斯科码从小到大排列
                       sb.append((char) i);
                    }
                }
                max--;
            }
        }
    }
}
