package com.xsc.nanjing.huawei2;

import java.util.Scanner;

//自守数的题目
public class test15 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while(sc.hasNext()){
            int n = sc.nextInt();

            int cnt = 0;
            for(int i = 0; i<=n; i++){

                //取值判断
                int temp = i;
                int j = 1;

                //中间的小处理很关键
                //并且这里是需要更新多次的
                //得用while
                while(temp != 0){
                    temp = temp/10;
                    j = j*10;
                }

                if( (i*i-i) %j == 0){
                    cnt++;
                }
            }
            System.out.println(cnt);
        }
        sc.close();
    }
}
