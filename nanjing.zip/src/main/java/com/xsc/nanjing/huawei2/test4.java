package com.xsc.nanjing.huawei2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//通过找规律的方法来写这个问题
public class test4 {
    public static void main(String[] args) {
        List<Integer> list = new ArrayList<>();
        list.add(1,3);
        Scanner sc = new Scanner(System.in);
        while(sc.hasNext()){
            int N = sc.nextInt();
            int first = 1;
            //用两层循环来搞定
            //第一层是觉得总共要输入几行
            for(int i = 1; i<=N; i++){
                //不管怎么搞，先输出first每行的第一个元素
                System.out.print(first);
                int tmp = first;
                //内层决定是这一行除了第一个数字外需要输出的
                //第一行总共五个元素，第二行总共四个元素
                for(int j = i+1; j<=N; j++){
                    tmp+=j;  //每个数字之前的差值其实是在变大的
                    System.out.print(" " + tmp);
                }
                System.out.println();
                first += i;
            }
        }
        sc.close();
    }
}
