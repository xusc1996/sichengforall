package com.xsc.nanjing.huawei2;

//验证asc码表
public class test16 {
    public static void main(String[] args) {
          int[]tmp = new int[150];
          tmp['a'] = 6;


          //这样可以打印A，打印字符
        System.out.println((char)65);

          //实际上你会发现字符作为数组的下标一样可以用，会自动转成Asc码
        System.out.println(tmp[97]);  //a的asc码数值为97
        System.out.println(tmp['Z']);
    }
}
