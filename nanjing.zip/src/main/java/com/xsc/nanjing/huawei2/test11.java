package com.xsc.nanjing.huawei2;

import java.util.Scanner;

//判断24点的游戏
public class test11 {
        public static void main(String[]args){
            Scanner sc = new Scanner(System.in);
            while(sc.hasNext()){
                int x = sc.nextInt();
                int y = sc.nextInt();
                int z = sc.nextInt();

                int[][]m1 = new int[x][y];
                int[][]m2 = new int[y][z];
                int[][]r = new int[x][z];

                for(int i = 0; i<x; i++){
                    for(int j = 0; j<y; j++){
                        m1[i][j] = sc.nextInt();
                    }
                }

                for(int i = 0; i<y; i++){
                    for(int j = 0; j<z; j++){
                        m2[i][j] = sc.nextInt();
                    }
                }

                //这里要写一个三层暴力循环去进行矩阵乘法
                for(int i = 0; i<x; i++){
                    for(int j = 0; j<z; j++){
                        for(int k = 0; k<y; k++){
                            r[i][j] = r[i][j] + m1[i][k]*m2[k][j];
                        }
                    }
                }

                for(int i = 0; i<x; i++){
                    for(int j = 0; j<z; j++){
                        System.out.print(r[i][j]+" ");
                    }
                    System.out.println();
                }
            }
        }

    public static boolean check(int[]num, int[]tmp, double result){
        //外层循环是对实际数组
        for(int i = 1; i<num.length; i++){
            //内层判断是标志位,递归的时候如果是1就跳过了
            if(tmp[i] == 0){
                 tmp[i] = 1;
                 if(check(num,tmp,result+num[i])
                         ||check(num,tmp,result-num[i])
                         ||check(num,tmp,result*num[i])
                         ||check(num,tmp,result/num[i])){
                     return true;
                 }
                 tmp[i] = 0;
            }
        }
        if(result== 24){
            return true;
        }else {
            return false;
        }
    }
}
