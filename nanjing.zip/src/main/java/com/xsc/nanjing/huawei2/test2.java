package com.xsc.nanjing.huawei2;

import java.util.Scanner;

//还是类似字母转换的题目
//这个题目的难点在于排序
//在于非字母的字符不能变得在原来的位置
public class test2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (sc.hasNext()) {
            String str = sc.nextLine();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < str.length(); i++) {
                char c = str.charAt(i);
                if (Character.isLetter(c)) {
                    sb.append(c);
                }
            }
            //冒泡排序
            char[] cs = sb.toString().toCharArray();
            for (int i = 0; i < cs.length; i++) {
                for (int j = 0; j < cs.length - i - 1; j++) {
                    if (Character.toLowerCase(cs[j]) - Character.toLowerCase(cs[j + 1]) > 0) {
                        char temp = cs[j];
                        cs[j] = cs[j + 1];
                        cs[j + 1] = temp;
                    }
                }
            }
            StringBuilder result = new StringBuilder();
            int index = 0;
            for (int i = 0; i < str.length(); i++) {
                char c = str.charAt(i);
                if (Character.isLetter(c)) {
                    result.append(cs[index]);
                    index++;
                } else {
                    result.append(c);
                }
            }

            System.out.println(result.toString());
        }

        sc.close();
    }
}
