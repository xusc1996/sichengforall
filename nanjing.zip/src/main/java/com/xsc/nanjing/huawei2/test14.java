package com.xsc.nanjing.huawei2;

import java.util.HashMap;
import java.util.Scanner;

//扑克牌比较大小
//默认输入的牌不会出现相同
public class test14 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while(scanner.hasNext()){
            String s = scanner.nextLine();
            //以-分割左右两手牌
            //输入的形式
            String[] arr = s.split("-");
            System.out.println(helper(arr[0],arr[1]));
        }
    }

    private static String helper(String s1, String s2) {
        HashMap<String,Integer> map = new HashMap<>();
        map.put("3",3);
        map.put("4",4);
        map.put("5",5);
        map.put("6",6);
        map.put("7",7);
        map.put("8",8);
        map.put("9",9);
        map.put("10",10);
        map.put("J",11);
        map.put("Q",12);
        map.put("K",13);
        map.put("A",14);
        map.put("2",15);
        map.put("joker",16);
        map.put("JOKER",17);
        if(s1.equals("joker JOKER") || s1.equals("JOKER joker")){
            return s1;
        }
        else if(s2.equals("joker JOKER") || s2.equals("JOKER joker")){
            return s2;
        }

        //利用HashMap来把str转换成数字
        String[]arr1 = s1.split(" ");
        int n1 = map.get(arr1[0]);
        String[]arr2 = s2.split(" ");
        int n2 = map.get(arr2[0]);

        //对于炸弹的判断三种
        if(isBoom(s2) && isBoom(s1)){
            return n1>n2?s1:s2;
        }
        else if(isBoom(s2) && !isBoom(s1)){
            return s2;
        }
        else if(isBoom(s1) && !isBoom(s2)){
            return s1;
        }

        //长度相同可以比较大小
        else if(arr1.length == arr2.length){
            return n1>n2?s1:s2;
        }
        else{
            return "error";
        }
    }

    private static boolean isBoom(String s) {
        //你会发现每一手牌需要做处理之前必须要
        //split函数一下
        String[]str = s.split(" ");

        if(str.length != 4) return false;

        String cur = str[0];
        //比较你的四张牌是不是全部相同
        for(int i = 1; i<4; i++){
            if(cur!=str[i]){
                return false;
            }
        }
        return true;
    }
}
