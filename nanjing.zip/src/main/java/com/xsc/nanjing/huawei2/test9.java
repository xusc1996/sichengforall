package com.xsc.nanjing.huawei2;

import java.util.Scanner;

//GC序列
public class test9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while(scanner.hasNext()){
            String str = scanner.nextLine();
            int num = scanner.nextInt();
            String res = getString(str,num);
            System.out.println(res);
        }
        scanner.close();
    }

    //找到GC比例最高的子串
    public static String getString(String str, int num){
        int maxGC = 0;
       //返回值
        String res = "";

        //循环开始于0，循环结束于最后一个子串的开始字母
        //因为再往后，构成不了一个子串
        for(int i = 0; i<str.length()-num+1; i++){
            //统计一下这个子串GC出现的次数
            int tmp = GCcount(str.substring(i,i+num));

            //取最大值
            if(tmp>maxGC){
                maxGC = tmp;
                //到循环结束诞生GC比例最高的子串
                res = str.substring(i,i+num);
            }
        }
        return res;
    }


    //统计GC的个数
    public static int GCcount(String s){
       int count = 0;
       for(int i = 0; i<s.length(); i++){
           if(s.charAt(i)=='C' || s.charAt(i) == 'G'){
               count++;
           }
       }
       return count;
    }
}
