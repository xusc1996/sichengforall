package com.xsc.nanjing.huawei2;

import java.util.Arrays;
import java.util.Scanner;

//名字漂亮度
public class test5 {
    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        while(sc.hasNext()){
            int n = sc.nextInt();

            for(int i =0; i<n; i++){
                String str = sc.nextLine();
                char[]chars = str.toCharArray();

                //计算26个字母出现的次数并排序一下
                int[]cnt = new int[26];
                for(int j = 0; j<str.length(); j++){
                    cnt[chars[i]-'a']++;
                }
                Arrays.sort(cnt);

                int max = 26;
                int pld = 0;
                for(int k = 25; k>=0; k--){
                    pld += cnt[k]*max;
                    max--;
                }
                System.out.println(pld);
            }
        }
        sc.close();
    }
}
