package com.xsc.nanjing.huawei2;

import java.util.Scanner;

public class test7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNext()){
            String str = scanner.nextLine();
            char[] chars = str.toCharArray();
            for(int i = 0; i<chars.length; i++){
                //判断只出现一次的字符
                if(str.indexOf(chars[i]) == str.lastIndexOf(chars[i])){
                    System.out.println(chars[i]);
                    break;
                }
                //实际上这个条件
                //是执行到最后一位，并且，最后一位元素在之前出现过！！
                if(i == chars.length-1) {
                    System.out.println(-1);
                }
            }
        }
    }
}
