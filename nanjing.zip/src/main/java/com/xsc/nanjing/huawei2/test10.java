package com.xsc.nanjing.huawei2;

import java.util.Scanner;

//找到最长的子串
public class test10 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while(sc.hasNext()){
            //先来四个初始
            String s1 = sc.nextLine();
            String s2 = sc.nextLine();
            String max = s1.length()>=s2.length()?s1:s2;
            String min = s1.length()>=s2.length()?s2:s1;

            //设置一下子串的初始长度
            int len = 0;
            String s = "";

            //写一个两层循环,都是短的字符串进行
            for(int i = 0; i<min.length(); i++){
              for(int j = i+1; j<min.length(); j++){
                   //我们要找到最长的子串，每次都要大于这个len
                   //同时len也在随之改变
                   if(max.contains(min.substring(i,j)) && j-i>len){
                       len = j-i;
                       s = min.substring(i,j);
                   }
              }
            }
            System.out.println(s);
        }
    }
}
