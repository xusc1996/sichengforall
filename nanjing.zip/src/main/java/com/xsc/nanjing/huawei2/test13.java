package com.xsc.nanjing.huawei2;

import java.util.Scanner;

//本题是正则表达式的转换
public class test13 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while(sc.hasNext()){
            String reg = sc.nextLine();
            String str = sc.nextLine();
            //做出响应的替换,这就是正则表达式的规范
            reg = reg.replaceAll("\\?","[0-9A-Za-z]{1}");
            reg = reg.replaceAll("\\*","[0-9A-Za-z]{0,}");
            reg = reg.replaceAll("\\.","\\\\.");
            boolean result = str.matches(reg);
            System.out.println(result);
        }
    }
}
