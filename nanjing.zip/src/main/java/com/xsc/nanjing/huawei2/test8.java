package com.xsc.nanjing.huawei2;

import java.util.Scanner;

//实际上这个题就是一个判断是否为质数
//另外要记住2以内的数不是素数
//从中间想两边去找
public class test8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while(sc.hasNext()){
            int num = sc.nextInt();
            int l = num/2;
            int m = num/2;
            //任意一个偶数可以由俩素数组成
            while (l>2 && m<num-2){
               //涉及到唯一性，需要break
                if(helper(l) && helper(m) && m+l==num){

                    System.out.println(l);
                    System.out.println(m);

                    break;
               }
               else{
                    l--;
                    m++;
                }
            }

        }
    }

    //用于简单判断n是否为质数
    public static boolean helper(int n){
        if(n<=2) return false;
        for(int i=2;i<n;i++){
            if(n%i==0) return false;
        }
        return true;
    }
}
