package com.xsc.nanjing.huawei2;

import java.util.Scanner;

//矩阵乘法 暴力拆解
public class test12 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while(sc.hasNext()){
            //x是第一个矩阵的行数
            //y是第一个矩阵的列数和第二个矩阵的行数
            //这样可保证两个矩阵可以相乘
            int x = sc.nextInt();
            int y = sc.nextInt();
            int z = sc.nextInt();

            int[][]m1 = new int[x][y];
            int[][]m2 = new int[y][z];
            int[][]r = new int[x][z];

            for(int i = 0; i<x; i++){
                for(int j = 0; j<y; j++){
                    m1[i][j] = sc.nextInt();
                }
            }
            for(int i = 0; i<y; i++){
                for(int j = 0; j<z; j++){
                    m2[y][z] = sc.nextInt();
                }
            }

            //上面是录入两个需要相乘的矩阵
            //接着我们对两个矩阵来相乘
            for(int i = 0; i<x; i++){
                for(int j = 0; j<z; j++){
                    for(int k = 0; k<y; k++){
                        //关键就是这一步，需要一个乘连加解决问题
                        r[i][j] = r[i][j] + r[i][k]*r[k][j];
                    }
                }
            }

            for(int i = 0; i<x; i++){
                for(int j = 0; j<z; j++){
                    System.out.print(r[i][j]);
                }
                System.out.println();
            }
        }
    }
}
