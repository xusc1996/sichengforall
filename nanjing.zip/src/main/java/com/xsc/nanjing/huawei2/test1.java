package com.xsc.nanjing.huawei2;

import java.util.Scanner;

//密码对应问题
public class test1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String str = scanner.nextLine();
        PassWord(str);
    }

    public static void PassWord(String str){
        if(str == null || str == ""){
            System.out.println(str);
        }

        StringBuffer sb = new StringBuffer();
        char[] chars = str.toCharArray();
        for(int i = 0; i<chars.length; i++){
            if(chars[i]<='c' && chars[i]>='a'){
                sb.append('2');
            }
            else if(chars[i]>='d' && chars[i]<='f'){
                sb.append('3');
            }
            else if(chars[i]>='g' && chars[i]<='i'){
                sb.append('4');
            }
            else if(chars[i]>='j' && chars[i]<='l'){
                sb.append('5');
            }
            else if(chars[i]>='m' && chars[i]<='o'){
                sb.append('6');
            }
            else if(chars[i]>='p' && chars[i]<='s'){
                sb.append('7');
            }
            else if(chars[i]>='t' && chars[i]<='v'){
                sb.append('8');
            }
            else if(chars[i]>='w' && chars[i]<='z'){
                sb.append('9');
            }

            //单独讨论一下大写字母
            else if(chars[i] == 'Z'){
                sb.append('a');
            }
            else if(chars[i] < 'Z' && chars[i] >= 'A'){
                char c = (char) (chars[i] + 'a' - 'A' + 1);
                sb.append(c);
            }
            else{
                sb.append(chars[i]);
            }

        }
        System.out.println(sb.toString());
    }
}
