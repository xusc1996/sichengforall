package com.xsc.nanjing.huawei;

import java.util.Scanner;

//完全数
public class test8 {
    public static void main(String[] args) {
        Scanner ss = new Scanner(System.in);
        while(ss.hasNext()){
            int i = ss.nextInt();
            int count = 0;
            //讨论从1到i中的完全数，当然带入函数的值应该是a
            for (int a = 2; a<=i; a++){
                if(isPerfect(a)==true){
                    count++;
                }
            }
            //记住我们输出答案要在循环里面
            System.out.println(count);
        }
    }

    public static boolean isPerfect(int num){
       int sum = 0;
       //不可以把自身算进去，这也就是为啥1不能成为完全数的理由
       for(int i = 1; i<num; i++){
           if(num%i == 0){
               sum += i;
           }
       }
       if(sum == num){
           return true;
       }
       return false;
    }
}
