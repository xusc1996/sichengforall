package com.xsc.nanjing.huawei;

import java.util.Scanner;

//依旧是翻转字符串的题目
//除了用库函数
//还可以用遍历翻转输出
public class test4 {
    public static void main(String[] args) {
        Scanner a = new Scanner(System.in);
        while (a.hasNext()){
            String str = a.nextLine();
            //注意还是要把这个字符串转换为字符数组
            char[]chars = str.toCharArray();
            for(int i = chars.length-1; i>=0; i--){
                //这里的输出要注意！！
                System.out.print(chars[i]);
            }
            System.out.println();
        }
      }
}
