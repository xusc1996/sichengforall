package com.xsc.nanjing.huawei;

import java.util.Scanner;

//杨辉三角形
public class test7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while(scanner.hasNext()){
            int num = scanner.nextInt();
            if(num<2){
                System.out.println(-1);
                continue;
            }
            else if(num%4 == 3 || num%4 ==1){
                System.out.println(2);
                continue;
            }
            else if(num%4 == 2){
                System.out.println(4);
                continue;
            }
            else if(num%4 == 0){
                System.out.println(3);
                continue;
            }
        }
    }
}
