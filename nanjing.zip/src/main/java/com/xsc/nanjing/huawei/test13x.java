package com.xsc.nanjing.huawei;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

//实际上这个题并没有那么复杂
//只需要设置一个标志位即可！
public class test13x {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s = br.readLine();

            //转换成字符数组
            char[]chars = s.toCharArray();
            //创建stringBuffer来完成录入，最后的输出也是
            StringBuffer sb = new StringBuffer();

            boolean flag = false;
            int count = 1;
            for(int i = 0; i<chars.length; i++){
                //出现引号的话需要拿出来讨论
                if(chars[i] == '\"'){
                    //我们判断flag是否为true
                    //实际上就是转换一下flag的布尔值
                    //遇到引号就打个标记
                    //两个引号回到初始！
                    flag = flag?false:true;
                    continue;
                }

                //设置三个if语句！
                if(chars[i] != ' '){
                    sb.append(chars[i]);
                }
                if(chars[i] == ' ' && flag){
                    sb.append(chars[i]);
                }
                //如果标记为false，则开始下一个命令！
                if(chars[i] == ' ' && !flag){
                    sb.append("\n");
                    count++;
                }
            }
            System.out.println(count+"\n"+sb.toString());
        }
    }
