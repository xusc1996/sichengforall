package com.xsc.nanjing.huawei;

//鸡兔同笼问题，解方程的方式去做

//最后列出的式子是14x+8y=200
//用两层循环解决这个问题
public class test11 {
    public static void main(String[] args) {
        for(int x = 0; x<15; x++){
            for(int y = 0; y<=25; y++){
                if(14*x + 8*y == 200){        //注意细节，要加括号！！！
                    System.out.println(x+" "+y+" "+(100-x-y));
                }
            }
        }
    }
}
