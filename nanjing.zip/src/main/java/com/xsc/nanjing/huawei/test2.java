package com.xsc.nanjing.huawei;

import java.util.Scanner;

//二进制数1的个数
public class test2 {
    public static void main(String[] args) {
        Scanner a = new Scanner(System.in);

        //写一个循环就可以一直输入
        while (a.hasNext()){
            int num = a.nextInt();
            int count = 0;
            //将十进制数字转换为2进制数
            String toBinary = Integer.toBinaryString(num);
            for(int i = 0; i<toBinary.length(); i++){
                //遍历一下二进制字符串
                char c = toBinary.charAt(i);
                if(c=='1'){
                    count++;
                }
            }
            System.out.println(count);
        }
    }
}
