package com.xsc.nanjing.huawei;


import java.io.BufferedReader;

import java.io.InputStreamReader;

import java.io.IOException;

import java.util.HashMap;

//今日BOSS出现了
//匹配命令
public class test10 {
    public static void main(String[] args) throws IOException {

        /*
             *  字符输入流缓冲流
             *   java.io.BufferedReader 继承Reader
             *   读取功能read()   单个字符，字符数组
             *   构造方法：
             *       BufferedReader(Reader r)
             *       可以任意的字符输入流
             *        FileReader   InputStreamReader
             *         
             *       BufferedReader自己的功能
             *       String readLine() 读取文本\r\n

         */
                                                  //读一下输入流
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        //利用HashMap来存储这些命令
        HashMap<String,String> HMp = new HashMap<>();
        HMp.put("reset", "reset what");
        HMp.put("reset board", "board fault");
        HMp.put("board add", "where to add");
        HMp.put("board delete", "no board at all");
        HMp.put("reboot backplane", "impossible");
        HMp.put("backplane abort", "install first");

        //这里读入数据一定要记住！！！！ 读入一行，不在意空格
        //类似 nextLine
        String input = br.readLine();

        while (null!=input){
            //这里写的就是比较简单，实际上应该更复杂
            if(HMp.containsKey(input)){
                System.out.println(HMp.get(input));
            }
            else{
                System.out.println("unknown command");
            }

            //执行完毕一条命令，会调用这里自身形成循环
            input = br.readLine();
        }
    }
}
