package com.xsc.nanjing.huawei;

import java.util.Scanner;

//简单递归，养兔子问题
public class test6 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        while (s.hasNext()){
            int monthCount = s.nextInt();
            System.out.println(getTotal(monthCount));
        }
    }

    //新定义一个小递归的方法
    public static int getTotal(int months){
       if(months<3){
           return 1;
       }
       else{
           return getTotal(months-1)+getTotal(months-2);
       }
    }
}
