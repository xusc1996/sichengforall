package com.xsc.nanjing.huawei;


import java.util.Scanner;

//喝汽水的题目
//实际上每两个空瓶子就可以喝到一瓶汽水
public class test5 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        //进入了while循环拿值的话不自行终止，循环不会结束的
        while(s.hasNext()){
            int result = s.nextInt();
            if(result == 0){
                System.out.println();
            }
            else{
                System.out.println(result/2);
            }
        }
    }
}
