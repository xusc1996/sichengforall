package com.xsc.nanjing.huawei;

import java.util.Scanner;

//先写一下错误案例
//就四个案例，用split分割即可
public class test13 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while(scanner.hasNext()){
            String input = scanner.nextLine();
            //利用split函数转换一下
            String[] out = input.split(" ");
            System.out.println(out.length);
            for(int i = 0; i<out.length; i++){
                System.out.println(out[i]);
            }
        }
        scanner.close();
    }
}
