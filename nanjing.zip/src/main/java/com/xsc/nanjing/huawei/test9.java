package com.xsc.nanjing.huawei;

import java.util.Scanner;

//放苹果
public class test9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNext()){
            int m = scanner.nextInt();
            int n = scanner.nextInt();
            System.out.println(Apple(m,n));
        }
        scanner.close();
    }

    //递归函数
    public static int Apple(int m, int n){
      if(m<0||n<=0) return 0;
      if(m==0||n==1||m==1) return 1;
        return Apple(m,n-1)+Apple(m-n,n);
    }
}
