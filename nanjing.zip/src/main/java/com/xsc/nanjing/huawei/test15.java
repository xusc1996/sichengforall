package com.xsc.nanjing.huawei;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

//m的立方可以有m个连续计数累和形成
public class test15 {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s;
        while((s=br.readLine())!=null){
           //先把m的值从输入的字符串流中取出来
           long m = Integer.valueOf(s);
           //用这个计算公式算一下起始的奇数
           long a = m*m-m+1;
            System.out.print(a);
            for(int i = 0; i<m; i++){
                System.out.print("+"+(a+=2));
            }
            System.out.println();
        }
        br.close();
    }
}
