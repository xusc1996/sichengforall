package com.xsc.nanjing.huawei;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

//找到子串
public class test14 {
    public static void main(String[] args) throws IOException {
        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        String str1 = "";
        String str2 = "";

        //注意这里是一行一行的读入
        while((str1=bf.readLine())!=null && (str2=bf.readLine())!=null){
            //先简单准备
            int max = 0;
            char[]char1 = str1.toCharArray();
            char[]char2 = str2.toCharArray();
            //简单的两层for循环
            for(int i = 0; i<str1.length(); i++){
                for(int j = 0; j<str2.length(); j++){
                    //注意这里要重新分配下标
                    int t1 = i;
                    int t2 = j;
                    //计数器
                    int count = 0;
                    while(char1[t1] == char2[t2]){
                       t1++;
                       t2++;
                       count++;
                       //得到最大值
                       max = Math.max(count,max);
                       if(t1 == char1.length || t2 == char2.length) break;
                    }
                }
            }
            System.out.println(max);
        }
    }
}
