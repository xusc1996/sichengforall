package com.xsc.nanjing.huawei;

import java.util.Scanner;

//翻转字符串的题目
public class test3 {
    public static void main(String[] args) {
        Scanner a = new Scanner(System.in);
        //这里解释一下next和nextLine的区别，前者遇到空格就会停下
        //使用nextLine()方法时，不将空格看做是两个字符串的间隔，
        // 而是看作字符串的一部分，返回时，它作为String类型一并返回：
        String str = a.nextLine();
        //利用字符串StringBuffer的内置方法
        StringBuffer rs = new StringBuffer(str);
        rs.reverse();
        System.out.println(rs);
    }
}
