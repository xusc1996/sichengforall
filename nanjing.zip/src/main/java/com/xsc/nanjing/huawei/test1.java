package com.xsc.nanjing.huawei;

import java.util.Scanner;

public class test1 {
    public static void main(String[] args) {
        //输入并取到a值
        Scanner in = new Scanner(System.in);
        double a = in.nextDouble();

        //先强制转换，然后取整操作
        int b = (int)a;

        if((b-a)>0.5){
            b = (int)(a+0.5);
        }

        System.out.println(b);
    }
}
