package com.xsc.nanjing.huawei;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

//最大回文数字串
public class test17 {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s;
        while((s = br.readLine())!=null){
            StringBuffer sb = new StringBuffer();
            sb.append(s);
            //我们这里利用StringBuffer翻转函数
            sb.reverse();
            int max = 0;
            //两层循环
            for(int i = 0; i<s.length(); i++){
                for(int j = i+1; j<s.length(); j++){
                    //这样比较s和sb就是在核对回文序列
                    if(s.contains(sb.substring(i,j))){
                        if(j-i>max){
                            max = j - i;
                        }
                    }
                }
            }
            System.out.println(max);
        }
    }
}
