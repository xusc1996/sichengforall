package com.xsc.nanjing.huawei;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

//查找大写字母
public class test16 {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s;
        while((s=br.readLine())!=null){
            char[]chars = s.toCharArray();
            int count = 0;
            for(char c : chars){
                if(c >= 'A' && c <= 'Z'){
                    count++;
                }
            }
            System.out.println(count);
        }
        br.close();
    }
}
