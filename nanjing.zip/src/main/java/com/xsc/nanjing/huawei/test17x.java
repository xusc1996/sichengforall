package com.xsc.nanjing.huawei;


//虽然这个回文串有点不对，但还是先写吧
import java.io.*;

public class test17x {
    public static void main(String[]args) throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s;
        while((s = br.readLine())!=null){
            //只有用这个才能翻转
            StringBuffer sb = new StringBuffer(s);
            sb.reverse();
            int max = 0;
            for(int i = 0; i<s.length(); i++){
                for(int j = i+1; j<s.length(); j++){
                        //利用原来的字符串和翻转后的比较
                        //用的是subString函数
                    if(s.contains(sb.substring(i,j))){
                        //取一下最大的max值
                        max = Math.max(max,(j-i));
                    }
                }
            }
            System.out.println(max);
        }
    }
}
