package com.xsc.nanjing.huawei;

import java.util.Scanner;

//简单的日期计数
//实际上就是把每个月的天数算进去，包括闰年
public class test12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while(scanner.hasNext()){
            int year = scanner.nextInt();
            int month = scanner.nextInt();
            int day = scanner.nextInt();
            int Day = outDay(year,month,day);
            System.out.println(Day);
        }
        scanner.close();
    }

    private static int outDay(int year, int month, int day){
        //先写一下正常的每月天数
        int[]Day = {31,28,31,30,31,30,31,31,30,31,30,31};

        //记住闰年的判断条件！！！！
        if(year % 4 == 0 && year % 100 != 0 || year % 400 ==0){
            Day[1] = 29;
        }

        //写一下不对的判断条件
        if(year<=0||month<=0||day<=0||month>12||day>Day[month-1]){
            return -1;
        }



        int sum = 0;
        //每年的从1月Day[0]开始计算下去
        for(int i = 0; i<month-1; i++){
            //把月加上
            sum += Day[i];

        }
        //最后加上天数即可！
        return sum+day;
    }
}
