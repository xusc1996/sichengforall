package com.xsc.nanjing.Sword;

public class test1 {
    public static void main(String[] args) {
//        String str = "adcap";
//        System.out.println(str.substring(3));
//     for(int i = 0; i<5; i++){
//         System.out.println(i);
//     }
//                             实际上这边可以写e01
        System.out.println(.9);
    }
}
