package com.xsc.nanjing.service.impl;

import com.xsc.nanjing.Mapper.CourseOrderMapper;
import com.xsc.nanjing.model.CourseOrder;
import com.xsc.nanjing.model.PageResult;
import com.xsc.nanjing.service.ICourseOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CourseOrderService implements ICourseOrderService {

    @Autowired
    CourseOrderMapper order;

    @Override                                                 //总之我们就是这样传递数值和条件，因为使用的是前端工具layui
    public PageResult<CourseOrder> findPageResult(CourseOrder condition, int page, int pageSize) {
        PageResult<CourseOrder> result = new PageResult<>();
        result.setCode(0);

        //可以先把查询参数设置为空,这里实际上还没开始用这个参数
        Map<String,Object> params = new HashMap<>();

        //这里不是用插件，而是手动来设置
        //完成分页首先还是用SQL语句来实现的
        params.put("start",(page-1)*pageSize);
        params.put("pageSize",pageSize);

        //获取总的记录数，用的是mapper里的方法，也就是直接调数据库！！！！
        int totalCount = order.findCountByMap(params);
        result.setCount(totalCount);

        //获取查询的数据
        List<CourseOrder> list = order.findListByMap(params);


        result.setData(list);

        return result;
    }

    @Override
    public void save(CourseOrder courseOrder) {
       order.insert(courseOrder);
    }

    @Override
    public CourseOrder findByOrderId(String order_id) {
        return order.findByOrder(order_id);
    }

    @Override
    public void deleteByOrderId(String order_id) {
        order.deleteById(order_id);
    }

    @Override
    public void update(CourseOrder courseOrder) {
        order.updateById(courseOrder);
    }
}
