package com.xsc.nanjing.service;

import com.xsc.nanjing.model.CourseOrder;
import com.xsc.nanjing.model.PageResult;

public interface ICourseOrderService {

    //分页查询的方法，暂时的限制条件只是摆设
    public PageResult<CourseOrder> findPageResult(CourseOrder condition,int page,int pageSize);


    public void save(CourseOrder courseOrder);

    public CourseOrder findByOrderId(String order_id);

    public void deleteByOrderId(String order_id);

    void update(CourseOrder courseOrder);
}
