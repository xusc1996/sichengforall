package com.xsc;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


//mybatis+自带的启动器这里去写两个mapper
@MapperScan({"com.xsc.mapper","com.xsc.Generator.mapper"})
//不加上面这部，IOC容器里是没有mapper的，没有扫描进去接口中的studentmapper
@SpringBootApplication
public class MybatisPlusApplication {

    public static void main(String[] args) {
        SpringApplication.run(MybatisPlusApplication.class, args);
    }

}
