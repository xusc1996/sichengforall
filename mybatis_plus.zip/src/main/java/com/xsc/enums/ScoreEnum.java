package com.xsc.enums;

import com.baomidou.mybatisplus.core.enums.IEnum;

public enum ScoreEnum implements IEnum<Integer> {
    GOOD(60,"不错及格了"),
    GREAT(70,"其实考得很不错");

    private Integer code;
    private String msg;

    ScoreEnum(Integer code, String msg) {
        this.msg = msg;
        this.code = code;

    }

    @Override
    public Integer getValue() {
        return this.code;
    }
}
