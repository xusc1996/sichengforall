package com.xsc.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.xsc.enums.ScoreEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
//请你把实体类的名字和数据库中的对应起来或者添加注解
@TableName(value = "stu")
public class Student {

    @TableId(type = IdType.INPUT)
    private Long id;

    @TableField(value = "name")
    private String name;
    //设置为枚举类
    private int score;
    private Date birthday;
    @TableField(exist = false) //表示该字段不是数据库中字段，查询的时候跳过
    private String gender;

    @TableField(fill = FieldFill.INSERT)
    private Date createTime;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date updateTime;

    @Version  //设置为乐观锁对象
    private Integer version;

    @TableLogic
    private Integer deleted;

//    private Product product;
}
