package com.xsc.entity;

public class StudentVO {

    //就是为了给前端传递一些需要用到的字段，可以来自于好几个类
    private Long id;
    private String productname;
    private String studentId;
    private Double studentScore;
}
