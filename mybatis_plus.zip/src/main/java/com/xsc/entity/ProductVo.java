package com.xsc.entity;

import lombok.Data;

@Data
public class ProductVo {
    private Integer category;
    private Integer count;
    private String description;
    private Integer studentId;
    private String studentName;
}
