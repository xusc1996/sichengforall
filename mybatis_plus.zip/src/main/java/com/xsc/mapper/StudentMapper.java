package com.xsc.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xsc.entity.ProductVo;
import com.xsc.entity.Student;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StudentMapper extends BaseMapper<Student> {

    //但你需要连表查询，自定义一些查询语句，mybatis+框架已经不能帮到我们的时候，此时就需要重新向以前那样去定义东西了
    //就是通过注释的方式写select语句，在dao/mapper层。总结就是我们在mapper中定义那些开源框架所不具备的方法
    //之后再到你的test中调用这个方法

    //注意这里驼峰命名可以默认对应起来，student_id和studentId,没有对应起来的需要在SQL语句的后面追加实体类中的名字
    //比如下面的s.name studentName 这样对应起来即可
    @Select("select p.*,s.name studentName from product p ,stu s where p.student_id = s.id and s.id = #{id}")
    List<ProductVo> productList(Integer id);
}
