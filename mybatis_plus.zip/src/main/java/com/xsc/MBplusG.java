package com.xsc;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.config.DataSourceConfig;
import com.baomidou.mybatisplus.generator.config.GlobalConfig;
import com.baomidou.mybatisplus.generator.config.PackageConfig;
import com.baomidou.mybatisplus.generator.config.StrategyConfig;

public class MBplusG {
    //这是mybatisPlus自动生成MVC的启动方法
    public static void main(String[] args) {
        //创建generator对象
        AutoGenerator autoGenerator = new AutoGenerator();
        //数据源  实际上这一步就是代替了我们之前手动配置的时候写的yml文件
        DataSourceConfig dataSourceConfig = new DataSourceConfig();
        dataSourceConfig.setDbType(DbType.MYSQL);
        dataSourceConfig.setUrl("jdbc:mysql://localhost:3306/bootmybatis?serverTimezone=UTC&useLegacyDatetimeCode=false&useSSL=false&useUnicode=true&characterEncoding=UTF-8");
        dataSourceConfig.setUsername("root");
        dataSourceConfig.setPassword("password");
        dataSourceConfig.setDriverName("com.mysql.cj.jdbc.Driver");
        //将数据源装进去
        autoGenerator.setDataSource(dataSourceConfig);

        //全局配置
        GlobalConfig globalConfig = new GlobalConfig();
        //指定路径MVC框架
        globalConfig.setOutputDir(System.getProperty("user.dir")+"/src/main/java");  //这里设置你要创建文件的所在目录
        globalConfig.setOpen(false);
        globalConfig.setAuthor("老徐盖饭");
        //设置好全局配置后自动装载一下
        autoGenerator.setGlobalConfig(globalConfig);

        //包信息
        PackageConfig packageConfig = new PackageConfig();
        packageConfig.setParent("com.xsc");
        packageConfig.setModuleName("Generator");
        packageConfig.setController("controller");
        packageConfig.setMapper("mapper");
        packageConfig.setService("service");
        packageConfig.setServiceImpl("serviceImpl");
        packageConfig.setEntity("entity");
        //设置好MVC三层的信息也要装载一下
        autoGenerator.setPackageInfo(packageConfig);

        //配置策略
        StrategyConfig strategyConfig = new StrategyConfig();
        //如果是选取其中的几张表来生成，只需要设置一下涵盖的表就可以了
//        strategyConfig.setInclude("stu");
        strategyConfig.setEntityLombokModel(true);
        autoGenerator.setStrategy(strategyConfig);

        autoGenerator.execute();

    }
}
