package com.xsc.Generator.serviceImpl;

import com.xsc.Generator.entity.Product;
import com.xsc.Generator.mapper.ProductMapper;
import com.xsc.Generator.service.IProductService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 老徐盖饭
 * @since 2021-01-10
 */
@Service
public class ProductServiceImpl extends ServiceImpl<ProductMapper, Product> implements IProductService {

}
