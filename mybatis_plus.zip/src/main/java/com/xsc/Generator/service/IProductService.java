package com.xsc.Generator.service;

import com.xsc.Generator.entity.Product;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 老徐盖饭
 * @since 2021-01-10
 */
public interface IProductService extends IService<Product> {

}
