package com.xsc.Generator.mapper;

import com.xsc.Generator.entity.Product;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 老徐盖饭
 * @since 2021-01-10
 */
public interface ProductMapper extends BaseMapper<Product> {

}
