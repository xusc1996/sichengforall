package com.xsc.Generator.mapper;

import com.xsc.Generator.entity.Stu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 老徐盖饭
 * @since 2021-01-10
 */
@Repository
public interface StuMapper extends BaseMapper<Stu> {

}
