package com.xsc.Generator.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 老徐盖饭
 * @since 2021-01-10
 */
@Controller
@RequestMapping("/Generator/product")
public class ProductController {

}

