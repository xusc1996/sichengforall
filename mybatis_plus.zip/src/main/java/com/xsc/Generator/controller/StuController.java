package com.xsc.Generator.controller;


import com.xsc.Generator.service.IStuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 老徐盖饭
 * @since 2021-01-10
 */
@Controller
@RequestMapping("/Generator/stu")
public class StuController {

    @Autowired
    private IStuService iStuService;

    @GetMapping("/index")
    public ModelAndView index(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("index");
        //这里list中没有加任何参数，相当于我们本地测试时的selectList方法
        modelAndView.addObject("list",iStuService.list());
        return modelAndView;
    }

}

