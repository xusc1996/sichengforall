package com.xsc;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.xsc.entity.Student;
import com.xsc.mapper.StudentMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.thymeleaf.standard.expression.Each;

import javax.management.Query;
import javax.naming.Name;
import java.util.*;

@SpringBootTest
class MybatisPlusApplicationTests {

    @Autowired //面向接口编程，放入mapper层中的接口对象
    private StudentMapper mapper;

    @Test
    void contextLoads() {
        //查询所有的数据列出来
        List<Student> students = mapper.selectList(null);
        students.forEach(System.out::println);
    }

    @Test
    void save(){
        //插入一个数据
       Student student = new Student();
       student.setId(8L);
       student.setName("小李薇");
       student.setScore(70);
       mapper.insert(student);
        System.out.println(student);
    }

    @Test
    void update(){
        //修改一个数据,首先还是得查找出来
        Student student = mapper.selectById(7L);
        student.setName("直面恐惧吧");
        mapper.updateById(student);
    }

    @Test
    void delete(){
        QueryWrapper<Student> wrapper = new QueryWrapper<>();
        wrapper.eq("name","a");
        mapper.delete(wrapper);
    }

    //开始学习CRUD
    @Test
    void select(){
        //整体思路就是把条件语句给他打包，然后再去查询
        //如果要查询多个条件，就用，map去封装一下
        QueryWrapper wrapper = new QueryWrapper();

//        Map<String,Object>map = new HashMap<>();
//        map.put("name","徐思成");
//        map.put("score","60");
        //eq表示相等，一个条件时
//        wrapper.eq("name","徐思成");
//        wrapper.allEq(map);
//        wrapper.lt("score","61"); //查询分数小于61的
//        wrapper.ne("name","徐思成");  //ne就是年龄不等
//        wrapper.like("name","徐");//模糊查询   likeleft是以什么结尾 likeright是以什么开头

        //可以自己去写语句也可以 不用jt lt
//        wrapper.inSql("id","select id from stu where id < 10");
//        wrapper.inSql("score","select score from stu where score > 60");
//        wrapper.orderByAsc("score");//升序asc,降序desc


//        System.out.println(mapper.selectBatchIds(Arrays.asList(7,8,9)));
//        wrapper.gt("score",60);
//        System.out.println(mapper.selectCount(wrapper));
        //将查询的结果存储在map里，返回的是一个map集合
//        mapper.selectMaps(wrapper).forEach(System.out::println);
//        System.out.println("---------------------");
//        System.out.println(mapper.selectList(wrapper));


        //分页查询
//        Page<Student> page = new Page<>(1,2);
//        Page<Student> page1 = mapper.selectPage(page, null);
//        System.out.println(page1.getSize());
//        System.out.println(page1.getTotal());
//        System.out.println(page1.getRecords());

    }

    @Test
    void product(){
        System.out.println(mapper.productList(7));
    }



}
