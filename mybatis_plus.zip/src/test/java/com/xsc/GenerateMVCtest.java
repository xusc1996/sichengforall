package com.xsc;

import com.xsc.Generator.mapper.StuMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class GenerateMVCtest {

    @Autowired
    private StuMapper stuMapper;

    @Test
    void select(){
        System.out.println(stuMapper.selectList(null));
    }

}
