package com.xsc.controller;

import javax.naming.Name;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

//加了这个之后就可以直接url访问了
@WebServlet("/javaWeb")
public class servletx extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.getWriter().write("web");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        String name = req.getParameter("name");
        System.out.println("用户的姓名是"+name);
        String password =req.getParameter("password");
        System.out.println("用户的密码是"+password);
        req.setAttribute("name",name);
        req.setAttribute("password",password);
        req.getRequestDispatcher("/Result.jsp").forward(req,resp);
    }
}
