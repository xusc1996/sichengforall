package com.xsc.servlet;

import net.sf.json.JSONArray;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


//思路：通过AJAX异步处理可以实现省城市区的选定，下拉选定那种

@WebServlet("/location")
public class LocationServlet extends HttpServlet {

    private static Map<String,List<String>>citymap;
    private static Map<String,List<String>>provincemap;

    static{
        citymap = new HashMap<>();
        List<String> areas = new ArrayList<>();
        areas.add("红谷滩新区");
        areas.add("万达新区");
        areas.add("青山湖区");
        citymap.put("0-0",areas);

        //清空刚才的空间重新输入区
        areas = new ArrayList<>();
        areas.add("鸡腿新区");
        areas.add("火车站区");
        areas.add("绿树成荫区");
       citymap.put("0-1",areas);

       provincemap = new HashMap<>();
       List<String> cities = new ArrayList<>();
       cities.add("南昌市");
       cities.add("上饶市");
       provincemap.put("0",cities);

       //注意这里每次是清空List，不需要重新建立HashMap集合
        cities = new ArrayList<>();
        cities.add("南京市");
        cities.add("南通市");
        provincemap.put("1",cities);

        cities = new ArrayList<>();
        cities.add("杭州市");
        cities.add("宁波市");
        provincemap.put("2",cities);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String type = req.getParameter("type");
        resp.setCharacterEncoding("UTF-8");
        String id = req.getParameter("id");
        List<String> result = null;

        switch (type) {

            case "city":
                result = citymap.get(id);
                break;

            case "province":
               result = provincemap.get(id);
                break;
        }
        JSONArray jsonArray = JSONArray.fromObject(result);
        resp.getWriter().write(jsonArray.toString());


        //tips：本代码可以实现省到市，市到区的选择，但是无法互联
    }
}
