package com.xsc.servlet;

import com.xsc.entity.User;
import net.sf.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/test")
public class TestServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        //首先解释一下PrintWriter = response.getWriter();
        // wirte()是类PrintWriter提供的一个方法，是发送请求内容至页面，ajax常用到这个
        //response.write()是直接在页面输出内容
        //前端想要输出一个json格式，但是后端无法将一个java对象转换成json格式
    //    resp.getWriter().write(user.toString());
        //转换成json对象


        User user = new User(1,"徐思成",96.5);

        //记住转换中文乱码也是要看到底是resp还是req，不要盲目！！！
        resp.setCharacterEncoding("UTF-8");
        JSONObject jsonObject = JSONObject.fromObject(user);
        resp.getWriter().write(jsonObject.toString());

    }
}
