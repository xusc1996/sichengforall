package com.xsc.mockito.quickstart;

import com.xsc.mockito.controller.Account;
import com.xsc.mockito.controller.AccountDao;
import com.xsc.mockito.controller.AccountLoginController;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.servlet.http.HttpServletRequest;

import static org.hamcrest.CoreMatchers.anything;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AccountLoginControllerTest {
    //我们这里先注入需要mock的对象
    //controller里注入的要注入，controller里形式参数的方法也要注入

    private AccountLoginController accountLoginController;

    private AccountDao accountDao;

    private HttpServletRequest request;

    @Before
    public void setup(){

        //先建立好mock对象
        this.accountDao = Mockito.mock(AccountDao.class);
        this.request = Mockito.mock(HttpServletRequest.class);
        this.accountLoginController = new AccountLoginController(accountDao);

    }

    @Test
    public void testLoginSuccess(){

        Account acc = new Account();

        when(request.getParameter("username")).thenReturn("老徐盖饭");
        when(request.getParameter("password")).thenReturn("xsc961207");
        when(accountDao.findAccount(anyString(),anyString())).thenReturn(acc);

        assertThat(accountLoginController.login(request),equalTo("/index"));
    }

    @Test
    public void testLoginFailure(){

        Account acc = new Account();

        when(request.getParameter("username")).thenReturn("老徐盖饭");
        when(request.getParameter("password")).thenReturn("xsc961208");
        when(accountDao.findAccount(anyString(),anyString())).thenReturn(null);

        assertThat(accountLoginController.login(request),equalTo("/login"));
    }


    //这里测试的时候错误
    @Test
    public void Test505(){
        when(request.getParameter("username")).thenReturn("老徐盖饭");
        when(request.getParameter("password")).thenReturn("xsc961211");
        when(accountDao.findAccount(anyString(),anyString())).thenThrow(UnsupportedOperationException.class);

//        assertThat(accountLoginController.login(request),equalTo("/505"));
//        accountLoginController.login(request);
    }
}
