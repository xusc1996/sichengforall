package com.xsc.mockito.lesson318;

public class StubbingService {
    public int getI(){
        System.out.println("xxxxxxx");
        return 10;
    }

    public String getS(){
        System.out.println("dddddd");
        throw new RuntimeException();
    }
}
