package com.xsc.mockito.lesson318;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class StubbingTest {

    private List<String> list = new ArrayList<>();

    @Before
    public void init(){
        this.list = mock(ArrayList.class);
    }

    @Test
    public void howToUseMockito(){
        when(list.get(0)).thenReturn("first");
        //事实上我们并没有在arrayList里面放数据，但是要取到
        assertThat(list.get(0),equalTo("first"));


        //这里我们如果从list中拿任何数字都是抛出异常
        when(list.get(anyInt())).thenThrow(new RuntimeException());
       try {
           list.get(0);
           fail();
       }catch (Exception e){
           //检测是否是这个异常
           assertThat(e,instanceOf(RuntimeException.class));
       }

    }

    @Test
    public void howToStubbingVoidMethod(){
        //当我们测试一些没有返回值的方法
        //比如测试clear方法
        doNothing().when(list).clear();

        //执行clear方法
        list.clear();
        //我们测试一下clear方法是否仅仅被执行了一次
        verify(list,times(1)).clear();

        //如果我们想让list在执行clear方法的时候普抛出异常时
        doThrow(RuntimeException.class).when(list).clear();

        try {
            list.clear();
            fail();

        }catch (Exception e){
            assertThat(e,instanceOf(RuntimeException.class));
        }

    }

    @Test
    public void stubbingDoReturn(){
        when(list.get(0)).thenReturn("first");
        //实际上这个doReturn方法和when,thenReturn是一样的
        doReturn("second").when(list).get(1);
                   //我们先调用方法，后一半写返回值等于判断
        assertThat(list.get(0),equalTo("first"));
        assertThat(list.get(1),equalTo("second"));
    }

    @Test
    //迭代测试
    public void iterateStubbing(){
        //迭代调用，多个返回值，1，2，3，4
        when(list.size()).thenReturn(1,2,3,4);

        assertThat(list.size(),equalTo(1));
        assertThat(list.size(),equalTo(2));
        assertThat(list.size(),equalTo(3));
        assertThat(list.size(),equalTo(4));
        assertThat(list.size(),equalTo(4));
    }

    @Test
    public void StubbingWithAnswer()
    {                                  //answer里面可以加一些逻辑的东西
        when(list.get(anyInt())).thenAnswer(invocationOnMock ->
        {
            Integer index = invocationOnMock.getArgumentAt(0, Integer.class);
            //我们设置返回10倍输入的值
         return String.valueOf(index*10);
        });

        assertThat(list.get(0),equalTo("0"));
        assertThat(list.get(120),equalTo("1200"));
    }

    @Test
    public void stubbingwithRealCall(){
        StubbingService service = mock(StubbingService.class);

        when(service.getS()).thenReturn("xscxsc");
        assertThat(service.getS(),equalTo("xscxsc"));

        when(service.getI()).thenCallRealMethod();
        assertThat(service.getI(),equalTo(10));

        //复习一遍抛出异常的写法
        when(service.getS()).thenThrow(new RuntimeException());
        try{
            service.getS();
            fail();
        }catch (Exception e){
            assertThat(e,instanceOf(RuntimeException.class));
        }


    }

    @After
    public void destroy(){
        //mockito提供的方法reset,将所有的方法都重置
        Mockito.reset(this.list);
    }
}
