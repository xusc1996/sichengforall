package com.xsc.mockito.Lesson;

import com.xsc.mockito.controller.Account;
import com.xsc.mockito.controller.AccountDao;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Mockito.mock;

@RunWith(MockitoJUnitRunner.class)
public class MockByRunnerTest {

    @InjectMocks   //这里是执行真实的方法！！！！！
    AccountDao accountDao;

    @Test
    public void testMock(){
//        AccountDao accountDao = mock(AccountDao.class,Mockito.RETURNS_SMART_NULLS);
        //往常我们调用这个方法，会返回抛出异常
        //但是现在我们mock了这个类，因此就会有返回
        //但此时你不去打桩，你不对他们进行when，then的方法，那么打印出来的就会Null
        Account account = accountDao.findAccount("xsc", "xsc961207");
        System.out.println(account);
    }

}
