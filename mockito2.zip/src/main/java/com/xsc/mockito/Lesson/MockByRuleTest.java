package com.xsc.mockito.Lesson;

import com.xsc.mockito.controller.Account;
import com.xsc.mockito.controller.AccountDao;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;

import static org.mockito.Mockito.mock;

public class MockByRuleTest {
    @Rule
    public MockitoRule mockitoRule = MockitoJUnit.rule();

    @Test
    public void TestMock(){
        AccountDao accountDao = mock(AccountDao.class);
        Account account = accountDao.findAccount("xsc", "xsc961207");
        System.out.println(account);
    }
}
