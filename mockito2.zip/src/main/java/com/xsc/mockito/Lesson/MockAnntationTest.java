package com.xsc.mockito.Lesson;

import com.xsc.mockito.controller.Account;
import com.xsc.mockito.controller.AccountDao;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Answers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.Answer;

public class MockAnntationTest {

    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
    }

    @Mock(answer=Answers.RETURNS_SMART_NULLS)
    private AccountDao accountDao;

    @Test
    public void testMock(){
        Account account = accountDao.findAccount("xsc", "xsc961207");
        System.out.println(account);
    }
}
