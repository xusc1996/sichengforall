package com.xsc.mockito.controller;

public class AccountDao {
    public Account findAccount(String username,String password){
       throw new UnsupportedOperationException();
    }
}
