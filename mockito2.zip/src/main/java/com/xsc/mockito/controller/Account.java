package com.xsc.mockito.controller;

public class Account {
}
