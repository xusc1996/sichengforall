package com.xsc.mockito.Lesson7;

import javafx.scene.Parent;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TestArgs {
    @Test
    public void littleTest(){
        List<Integer> list = mock(ArrayList.class);
        when(list.get(0)).thenReturn(100);
        assertThat(list.get(0),equalTo(100));
        assertThat(list.get(1),nullValue());
    }

    @Test
    public void TestComplex(){

        Foo foo = mock(Foo.class);

        //打桩，如果你是Xsc的实例，那就返回100
        //测试IS A
        when(foo.function(isA(xxx.class))).thenReturn(100);

        //设置断言检查        这里mock出来的foo方法调用的是xxx类
        int result = foo.function(new xxx());
        assertThat(result,equalTo(100));

        result = foo.function(new xxc());
        //这里会发现没有匹配到具体的类，所以返回值是0
        assertThat(result,equalTo(0));

        //在我们进行any测试前要重置一下最好
        reset(foo);

        //实际上这个any啥也没干
        when(foo.function(any(Xsc.class))).thenReturn(100);
        xxx x = new xxx();
        //直接放入这个x对象就好
        result = foo.function(x);
        assertThat(result,equalTo(100));
    }


    //定义静态方法和接口
    static class Foo{
      int function(Xsc xsc){
          return xsc.work();
      }
    }

    //接口Xsc
    interface Xsc{
        int work();
    }

    //xsc有一个以上的实现类
    class xxx implements Xsc{

        @Override
        public int work() {
            throw new RuntimeException();
        }
    }

    class xxc implements Xsc{

        @Override
        public int work() {
            throw new RuntimeException();
        }
    }
}
