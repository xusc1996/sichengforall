package com.xsc.mockito.Lesson8;


public class SimpleService {

    public int method(int i, String s){
        throw new RuntimeException();
    }

    public int method1(int i, String s){
        throw new RuntimeException();
    }

    public void method2(int i, String s){
        throw new RuntimeException();
    }
}
