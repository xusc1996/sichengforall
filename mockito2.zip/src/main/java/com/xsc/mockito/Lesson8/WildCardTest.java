package com.xsc.mockito.Lesson8;

import com.sun.xml.internal.ws.policy.AssertionSet;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.Serializable;

import java.util.Collections;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class WildCardTest {

    @Mock
    private SimpleService simpleService;

    @Test
    public void wildcardMethod1(){
        //也就是说打桩没成功??????
        //问题的根本是你的打桩方法和后续的调用要匹配
        when(simpleService.method(anyInt(),anyString())).thenReturn(100);

        int result = simpleService.method(1, "xsc");
        assertThat(result,equalTo(100));

        int result1 = simpleService.method(1, "xsc");
        assertThat(result1,equalTo(100));
    }

    @Test
    public void WildCardMethod2(){
        when(simpleService.method(anyInt(),eq("xsc"))).thenReturn(100);
        when(simpleService.method(anyInt(),eq("xxx"))).thenReturn(200);

        int result = simpleService.method(1, "xsc");
        assertThat(result,equalTo(100));

        int result1 = simpleService.method(1, "xxx");
        assertThat(result1,equalTo(200));

    }

    @Test
    public void wildcardMethod3(){

        //要注意测试有返回值方法和无返回值方法是不一样的写法
        doNothing().when(simpleService).method2(anyInt(),anyString());
        simpleService.method2(1, "xscxsc");
        verify(simpleService,times(1)).method2(1, "xscxsc");

    }

    //因为我们在一个测试类中对上述的一个Service对象多次去mock可能会产生一些问题
    @After
    public void destroy(){
       reset(simpleService);
    }
}
