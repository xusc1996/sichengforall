package com.xsc.mockito.Lesson06;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SpyingTest {

    @Test
    public void testSpy(){

        //这个里面创建一个spy需要两个步骤，但是用注解的方式只需要一行
        List<String> reallist = new ArrayList<>();
        //用spy的方法创建一下list，而不是之前的spy的方式
        List<String> list = spy(reallist);

        list.add("xsc");
        list.add("xlv");

        //下列的两个断言成功说明执行了真正的方法
        //而我们mock中都是虚拟一个数字，不会去调用真正的数字
        assertThat(list.get(0),equalTo("xsc"));
        assertThat(list.get(1),equalTo("xlv"));
        //检测一下这个List是否为空，显然不是
        assertThat(list.isEmpty(),equalTo(false));

        //部分方法采用mock打桩的方式
        when(list.isEmpty()).thenReturn(true);
        when(list.size()).thenReturn(0);
        //我们接着用mock的方法来试一下
        //因为我们没有定义get方法的mock数据因此这里还是真实值
        assertThat(list.get(0),equalTo("xsc"));
        assertThat(list.get(1),equalTo("xlv"));
        assertThat(list.isEmpty(),equalTo(true));
        assertThat(list.size(),equalTo(0));
    }
}
