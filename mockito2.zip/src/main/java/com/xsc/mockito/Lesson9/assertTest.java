package com.xsc.mockito.Lesson9;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.either;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.core.Is.is;

@RunWith(MockitoJUnitRunner.class)
public class assertTest {

    @Test
    public void test(){
        int i = 10;
        assertThat(i,equalTo(10));
        assertThat(i,not(equalTo(20)));

        assertThat(i,is(10));
        assertThat(i,is(not(20)));

        double price = 23.45;   //可以either or选择，也可以用both
        assertThat(price,either(equalTo(23.45)).or(equalTo(23.54)));

        //我们可以写一下如果报错的提示
        assertThat("the double value is not checked",price, either(equalTo(23.99)).or(equalTo(23.78)));
    }
}
