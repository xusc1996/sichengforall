package com.xsc.InjectMocksTest.controller;

import com.xsc.InjectMocksTest.service.NameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

/**
 * Created by
 * Sicheng_XU
 * on 2021/3/23
 * 15:26
 * What hurts More...
 * The pain of hard work or the pain of regret?
 */
@Controller
public class NameController {

    @Autowired
    private NameService nameService;

    public void printName(){
        nameService.printMyName();
    }
}
