package com.xsc.InjectMocksTest.service;

import org.springframework.stereotype.Service;

/**
 * Created by
 * Sicheng_XU
 * on 2021/3/23
 * 15:26
 * What hurts More...
 * The pain of hard work or the pain of regret?
 */
@Service
public class NameService {
    public void printMyName(){
        System.out.println("xsc");
    }
}
