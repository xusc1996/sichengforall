package com.xsc.Entity;

import java.io.Serializable;

/**
 * Created by
 * Sicheng_XU
 * on 2021/3/19
 * 14:43
 */
public class Student implements Serializable {

}
