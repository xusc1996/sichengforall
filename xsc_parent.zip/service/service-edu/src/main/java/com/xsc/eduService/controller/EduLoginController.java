package com.xsc.eduService.controller;

import com.xsc.commonUtils.R;
import org.springframework.web.bind.annotation.*;


@RestController
@CrossOrigin
//表示请求的地址
@RequestMapping("/eduService/user")
public class EduLoginController {
    //login
    @PostMapping("login")
    public R login(){
                               //这里的token要对应前端
        return R.ok().data("token","admin");
    }
    //info
    @GetMapping("info")
    public R info(){

        return R.ok().data("roles","[admin]").data("name","admin").data("avatar","https://gss0.baidu.com/9fo3dSag_xI4khGko9WTAnF6hhy/zhidao/pic/item/d009b3de9c82d158c6e3f2bc800a19d8bc3e425d.jpg");
    }
}
