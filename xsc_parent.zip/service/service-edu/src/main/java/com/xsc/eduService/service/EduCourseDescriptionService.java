package com.xsc.eduService.service;

import com.xsc.eduService.entity.EduCourseDescription;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 课程简介 服务类
 * </p>
 *
 * @author 老徐盖饭哈哈
 * @since 2021-03-01
 */
public interface EduCourseDescriptionService extends IService<EduCourseDescription> {

}
