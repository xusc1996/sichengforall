package com.xsc.eduService.service.impl;

import com.xsc.eduService.entity.EduChapter;
import com.xsc.eduService.mapper.EduChapterMapper;
import com.xsc.eduService.service.EduChapterService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 课程 服务实现类
 * </p>
 *
 * @author 老徐盖饭哈哈
 * @since 2021-03-01
 */
@Service
public class EduChapterServiceImpl extends ServiceImpl<EduChapterMapper, EduChapter> implements EduChapterService {

}
