package com.xsc.eduService.service;

import com.xsc.eduService.entity.EduChapter;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 课程 服务类
 * </p>
 *
 * @author 老徐盖饭哈哈
 * @since 2021-03-01
 */
public interface EduChapterService extends IService<EduChapter> {

}
