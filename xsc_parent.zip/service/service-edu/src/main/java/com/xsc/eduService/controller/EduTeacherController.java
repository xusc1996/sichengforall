package com.xsc.eduService.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.xsc.commonUtils.R;
import com.xsc.eduService.entity.EduTeacher;
import com.xsc.eduService.entity.vo.teacherQuery;
import com.xsc.eduService.service.EduTeacherService;
import com.xsc.servicebase.exceptionHandler.HsException;
import io.lettuce.core.Limit;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.val;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 讲师 前端控制器
 * </p>
 *
 * @author 老徐盖饭哈哈
 * @since 2021-03-01
 */
@Api(description = "讲师管理")
//RC大法太香了
@RestController  //(controller+ResponseBody)一个是交给spring管理，一个是返回一个json对象
@RequestMapping("/eduService/edu-teacher")
@CrossOrigin
public class EduTeacherController {

    //如果通过浏览器访问地址 http://localhost:8001/eduservice/teacher/findAll

    @Autowired
    private EduTeacherService eduTeacherService;

    //1查询所有数据
    @ApiOperation(value = "查询所有讲师")
    @GetMapping("findAll")
    public R findAllTeacher(){

        //调用service里面的方法实现
        List<EduTeacher> list = eduTeacherService.list(null);


//        try{            //自定义异常处理演示
//            int i = 10/0;
//        }catch (Exception e){
//            throw new HsException(20002,"执行了自定义的异常");
//        }

        return R.ok().data("items",list);
    }

    //2逻辑删除
    @ApiOperation(value ="逻辑删除讲师")
    @DeleteMapping("{id}")       //下面表示填写
    public R removeTeacher(@ApiParam(name = "id",value = "讲师ID",required = true)
                                     @PathVariable String id)//这里表示：路径中传入一个id值，后面给他取出来
    {
        boolean b = eduTeacherService.removeById(id);
        if(b){
            return R.ok();
        }
        else{
            return R.error();
        }
    }

    //3分页查询讲师的方法
    //current当前页
    //limit每页记录数
    @GetMapping("pageTeacher/{current}/{limit}")
    public R pageListTeacher(@PathVariable long current,
                             @PathVariable long limit){

        //创建page对象  pageTeacher
        Page<EduTeacher>pageTeacher = new Page<>(current,limit);
        //调用方法实现分页
        //调用方法时，底层封装，把分页所有数据封装到pageTeacher对象里面
        eduTeacherService.page(pageTeacher,null);

        long total = pageTeacher.getTotal();
        List<EduTeacher> records = pageTeacher.getRecords();


        return R.ok().data("total",total).data("rows",records);
    }

    //4条件分页查询
    @PostMapping("pageTeacherCondition/{current}/{limit}")
    public R pageTeacherCondition(@PathVariable long current, @PathVariable long limit,
                                  //使用json格式传递数据，并将其封装到对象中去
                                  //注意使用RequestBody时需要用post提交方式，get取不到
                                  //并且要注明这些条件值都可以没有，required = false
                                  @RequestBody(required = false) teacherQuery teacherQuery){
        //创建配置对象
        Page<EduTeacher> pageTeacher = new Page<>(current,limit);

        //构建分页之前的条件
        QueryWrapper<EduTeacher> wrapper = new QueryWrapper<>();
        //mybatis里面的动态SQL语句

        //判断条件是否为空，如果不是空，就拼接上去
        String name = teacherQuery.getName();
        Integer level = teacherQuery.getLevel();
        String begin = teacherQuery.getBegin();
        String end = teacherQuery.getEnd();

        if(!StringUtils.isEmpty(name)){
            //加入这个条件,注意这里是模糊查询
            wrapper.like("name",name);
        }
        if(!StringUtils.isEmpty(level)){              //tips:这里的column后面的字段是MySQL表格中的
            wrapper.eq("level",level);
        }
        if(!StringUtils.isEmpty(begin)){              //tips:这里的column后面的字段是MySQL表格中的
            //gt = greater than   ge = 大于等于
            wrapper.ge("gmt_create",begin);
        }
        if(!StringUtils.isEmpty(end)){              //tips:这里的column后面的字段是MySQL表格中的
            wrapper.le("gmt_modified",end);
        }

       //最终还是service调用方法实现条件查询再分页
        eduTeacherService.page(pageTeacher,wrapper);

        long total = pageTeacher.getTotal();
        List<EduTeacher> records = pageTeacher.getRecords();


        return R.ok().data("total",total).data("rows",records);
    }

    //5添加讲师接口的方法
    @PostMapping("addTeacher")
    //你在分页的时候才需要在url中写出current,limit  而这里不需要，直接形参里面走一下eduTeacher即可
    public R addTeacher(@RequestBody EduTeacher eduTeacher){
        boolean b = eduTeacherService.save(eduTeacher);
        if(b){
            return R.ok();
        }else{
            return R.error();
        }
    }

    //6根据ID查询讲师
    @GetMapping("selectTeacherById/{id}")
    public R selectTeacherById(@PathVariable String id){
        EduTeacher byId = eduTeacherService.getById(id);
        //要注意value值不能加双引号直接调用上文的变量
        return R.ok().data("teacher",byId);
    }


    //7做一个讲师修改功能
    @PostMapping("updateTeacher")  //我们这里还是存入一个JSON格式对象进去
    public R updateTeacher(@RequestBody EduTeacher eduTeacher){

        boolean b = eduTeacherService.updateById(eduTeacher);

        if(b){
            return R.ok();
        }else{
            return R.error();
        }
    }
}

