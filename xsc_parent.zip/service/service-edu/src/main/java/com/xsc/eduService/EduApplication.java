package com.xsc.eduService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
//本来springBoot默认只会扫描周围的eduService文件夹下的东西，
//加上这个扫描规则后，service_base中的文件也会被扫描。
@ComponentScan(basePackages = {"com.xsc"})
//要注意我们一开始启动的时候呀有些东西需要注释掉在service中
public class EduApplication {
    public static void main(String[] args) {
        SpringApplication.run(EduApplication.class, args);
    }
}
