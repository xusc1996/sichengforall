package com.xsc.eduService.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 课程视频 前端控制器
 * </p>
 *
 * @author 老徐盖饭哈哈
 * @since 2021-03-01
 */
@RestController
@RequestMapping("/eduService/edu-video")
public class EduVideoController {

}

