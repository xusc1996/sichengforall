package com.xsc.eduService.mapper;

import com.xsc.eduService.entity.EduChapter;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 课程 Mapper 接口
 * </p>
 *
 * @author 老徐盖饭哈哈
 * @since 2021-03-01
 */
public interface EduChapterMapper extends BaseMapper<EduChapter> {

}
