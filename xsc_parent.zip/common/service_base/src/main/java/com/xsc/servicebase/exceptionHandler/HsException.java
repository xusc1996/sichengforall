package com.xsc.servicebase.exceptionHandler;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HsException extends RuntimeException{

    //一般的异常类，状态码加上异常信息
    @ApiModelProperty(value = "状态码")
    private Integer code;

    private String msg;
}
