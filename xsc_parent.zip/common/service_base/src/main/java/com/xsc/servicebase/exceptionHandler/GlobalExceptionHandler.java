package com.xsc.servicebase.exceptionHandler;

import com.xsc.commonUtils.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
@Slf4j//用到log4j注解
public class GlobalExceptionHandler {

    //指定执行了什么异常，这里是Exception.class，也就是说所有异常都会执行
    @ExceptionHandler(Exception.class)
    @ResponseBody//为了可以返回JSON数据
    public R error(Exception e){
        e.printStackTrace();
        return R.error().message("执行了全局异常");
    }

    //特定异常，你没有办法预知到将要发生的异常，所以使用较少
    @ExceptionHandler(ArithmeticException.class)
    @ResponseBody//为了可以返回JSON数据
    public R error(ArithmeticException e){
        e.printStackTrace();
        return R.error().message("执行了Arithmetic异常");
    }

    //自定义异常
    @ExceptionHandler(HsException.class)
    @ResponseBody//为了可以返回JSON数据
    public R error(HsException e){
        log.error(e.getMessage());//这个表示我们可以在遇到异常时去写入对应的文件中
        e.printStackTrace();
        return R.error().code(e.getCode()).message(e.getMsg());
    }
}
