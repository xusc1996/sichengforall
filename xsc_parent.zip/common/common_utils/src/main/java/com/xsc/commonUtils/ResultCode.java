package com.xsc.commonUtils;

//先建立一个接口用来表示返回的状态
public interface ResultCode {
    public static Integer SUCCESS = 20000;  //操作成功

    public static Integer ERROR = 20001;   //操作失败
}
