package com.xsc.service;

import com.xsc.pojo.Books;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface BookService {

//    实际上业务层和dao层也差不多，业务里会有些许的差别

    //增加一本书
    int addBook(Books book);
    //删除一本书
    int deleteBookById(int id);
    //更新一本书
    int updateBook(Books book);
    //根据id查询一本书
    Books queryBook(int id);
    //查询全部的书单
    List<Books> queryAllBook();
}
