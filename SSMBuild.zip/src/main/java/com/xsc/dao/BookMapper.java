package com.xsc.dao;

import com.xsc.pojo.Books;
import org.apache.ibatis.annotations.Param;

import java.util.List;


public interface BookMapper {
    //罗列一下你需要的方法

    //CRUD
    //增加一本书
    int addBook(Books book);
    //删除一本书
    int deleteBookById(@Param("bookID")int id);
    //更新一本书
    int updateBook(Books book);
    //根据id查询一本书
    Books queryBook(@Param("bookID")int id);
    //查询全部的书单
    List<Books> queryAllBook();
}
