DROP TABLE IF EXISTS `t_course_order`;
CREATE TABLE `t_course_order` (
  `uuid` varchar(36) DEFAULT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `wechat_no` varchar(255) DEFAULT NULL,
  `wechat_mark` varchar(255) DEFAULT NULL,
  `qq_no` varchar(15) DEFAULT NULL,
  `tel` varchar(15) DEFAULT NULL,
  `course_name` varchar(255) DEFAULT NULL,
  `course_price` varchar(20) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  `remark` text,
  `name` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;