package com.xsc.nanjing.JianZhi;

import java.util.ArrayList;

/**
 * Created by
 * Sicheng_XU
 * on 2021/3/31
 * 17:08
 * What hurts More...
 * The pain of hard work or the pain of regret?
 */
public class test1 {
    public static void main(String[] args) {
        int a = 1;
        int b = 9;
        ArrayList<Integer> list = new ArrayList<>();
        list.add(a);
        list.add(b);
//        System.out.println(list.get(1));
        System.out.println(Math.pow(2,3));
    }
}
