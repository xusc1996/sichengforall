package com.xsc.nanjing.Controller;


import com.xsc.nanjing.Entity.CURDResult;
import com.xsc.nanjing.Entity.CourseOrder;
import com.xsc.nanjing.Entity.PageResult;
import com.xsc.nanjing.Service.ICourseOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
@RequestMapping("/courseOrder")
public class CourseOrderController {

    @Autowired
    ICourseOrderService courseOrderService;

    @RequestMapping("list")
    public String list() {
        return "courseOrder/list";
    }

    //0根据id查询，双击展示详情
    @RequestMapping("detail")
    public String detail(Model model, String order_id) {
        CourseOrder order = courseOrderService.findOrderById(order_id);
        model.addAttribute("order", order);
        return "courseOrder/detail";
    }

    //1分页查询
    //直接访问listJson是会报错的，因为此时没形式参数传递
    //必须要用list页面去调用listJson，layui里面帮我们传递一下具体的分页数据就可以
    @GetMapping("listJson")    //service中要写的轻便
    @ResponseBody
    public PageResult<CourseOrder> listJson(CourseOrder condition, int page, int limit) {
        PageResult<CourseOrder> result = courseOrderService.findPageResult(condition, page, limit);
        return result;
    }

    //2跳转增加课程的页面
    @RequestMapping("add")
    public String add() {
        //跳转到add页面
        return "courseOrder/add";
    }

    //3.指向编辑按钮
    @RequestMapping("edit")
    public String edit(Model model, String order_id) {
        //先找到这个order，用序号
        CourseOrder order = courseOrderService.findOrderById(order_id);
        model.addAttribute("order", order); //这里面视图中存入的order最终是给html中的各个字段调用的

        return "courseOrder/edit";
    }

    //4定义增加或修改成功提交的按钮方法
    //tip: add和edit方法的提交按钮都调用这个方法
    @RequestMapping("save")
    @ResponseBody  //前端用的是jquery必须用Json格式接受一下
    //如果这里不写可能会提示错误：
    public CURDResult save(CourseOrder courseOrder) {

        System.out.println("我正在接受测试");

        CURDResult curdResult = new CURDResult();

        //这里要判断是添加还是修改
        if (StringUtils.isEmpty(courseOrder.getOrder_id())) {
            System.out.println("我正在插入数据");
            courseOrderService.save(courseOrder);
        } else {
            System.out.println("我正在修改数据");
            courseOrderService.update(courseOrder);
        }

        //实际上我们这里的返回值只是一个判断是否成功的东西，最后在检查里可以查看
        return curdResult;
    }

    //5删除一个order
    @RequestMapping("delete")
    @ResponseBody
    public CURDResult delete(String order_id) {
        CURDResult curdResult = new CURDResult();
        courseOrderService.deleteOrderById(order_id);
        return curdResult;
    }


}
