package com.xsc.nanjing.Mapper;

import com.xsc.nanjing.Entity.CourseOrder;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface CourseOrderMapper {
    public int findCountByMap(Map<String, Object> params);

    List<CourseOrder> findOrderByMap(Map<String, Object> params);

    void insert(CourseOrder courseOrder);

    CourseOrder findOrderById(String order_id);

    void updateOrderById(CourseOrder courseOrder); //无返回值

    void deleteById(String order_id);
}
