package com.xsc.nanjing.Entity;

import lombok.Data;

import java.util.List;

@Data
public class PageResult<T> {
    //0是成功，1是失败
    private int code;
    //如果是错误才会有这里的错误信息
    private String msg;
    //总记录数
    private int count;
    private List<T> data;
}
