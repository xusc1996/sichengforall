package com.xsc.nanjing.Entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CourseOrder {
    private String uuid;
    private String order_id;
    private String name;
    private String wechat_no;
    private String wechat_mark;
    private String qq_no;
    private String tel;
    private String course_name;
    private String course_price;
    private String order_date;
    private Date update_datetime;
    private String remark;
}
