package com.xsc.nanjing.HuaWeiMedium;

import java.util.BitSet;
import java.util.Scanner;

/**
 * Created by
 * Sicheng_XU
 * on 2021/3/25
 * 10:57
 * What hurts More...
 * The pain of hard work or the pain of regret?
 */
public class test3 {
    //出现了一个新东西就是位图，这个东西专业解决去重复
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while(sc.hasNext()){
            String line = sc.nextLine();
            BitSet bitSet = new BitSet(128);
            for(char c : line.toCharArray()){
             //判断位图中是否出现了c，get返回值是布尔判断
             //判断一下是否能够取到这个c,能取到就返回true
             if(!bitSet.get(c)){
                 //未出现就设置一下
                 bitSet.set(c);
             }
            }                   //利用这个函数可以统计出现的次数
            System.out.println(bitSet.cardinality());
        }
    }
}
