package com.xsc.nanjing.HuaWeiMedium;

import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

/**
 * Created by
 * Sicheng_XU
 * on 2021/3/25
 * 10:00
 * What hurts More...
 * The pain of hard work or the pain of regret?
 */
public class test2 {
    //用map来解决这个问题
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while(scanner.hasNext()){
            Map<Integer,Integer> map = new TreeMap<>();
            //首先要输入键值对的个数
            int n = scanner.nextInt();
            for(int i = 0; i<n; i++){
                int s = scanner.nextInt();
                int v = scanner.nextInt();
                if(map.containsKey(s)){
                    map.put(s,map.get(s)+v);
                }else {
                    map.put(s, v);
                }
            }
            //map的遍历输出不要忘记
            for(Integer key : map.keySet()){
                System.out.println(key + " " +map.get(key));
            }
        }
    }
}
