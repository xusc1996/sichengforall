package com.xsc.nanjing.HuaWeiMedium;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * Created by
 * Sicheng_XU
 * on 2021/3/24
 * 15:45
 * What hurts More...
 * The pain of hard work or the pain of regret?
 */
public class test1 {
    public static void main(String[]args) throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String str;
        while((str = br.readLine())!=null){
            char[]input = str.toCharArray();
            int lower = 0;
            int upper = 0;
            int num = 0;
            int symbol = 0;
            int score = 0;

            for(int i = 0; i<input.length; i++){
                if(input[i]>='a' && input[i]<='z'){
                    lower++;
                }
                else if(input[i]>='A' && input[i]<='Z'){
                    upper++;
                }
                else if(input[i]>='0' && input[i]<='9'){
                    num++;
                }
                else{
                    symbol++;
                }
            }

            if(input.length<=4){
                score+=5;
            }
            else if(input.length<=7 && input.length>=5){
                score+=10;
            }
            else if(input.length>=8){
                score+=25;
            }

            if(lower==0&&upper==0){
                score+=0;
            }
            else if(lower==0||upper==0){
                score+=10;
            }
            else if(lower!=0&&upper!=0){
                score+=20;
            }

            if(num==0){
                score+=0;
            }
            else if(num==1){
                score+=10;
            }
            else if(num>1){
                score+=20;
            }

            if(symbol==0){
                score+=0;
            }
            else if(symbol==1){
                score+=10;
            }
            else if(symbol>1){
                score+=25;
            }

            //奖励这里要反着写
            if(lower!=0&&upper!=0&&num!=0&&symbol!=0){
                score+=5;
            }
            else if(lower!=0||upper!=0&&num!=0&&symbol!=0){
                score+=3;
            }
            else if(lower!=0||upper!=0&&num!=0){
                score+=2;
            }

            if(score>=90){
                System.out.println("VERY_SECURE");
            }
            else if(score>=80){
                System.out.println("SECURE");
            }
            else if(score>=70){
                System.out.println("VERY_STRONG");
            }
            else if(score>=60){
                System.out.println("STRONG");
            }
            else if(score>=50){
                System.out.println("AVERAGE");
            }
            else if(score>=25){
                System.out.println("WEAK");
            }
            else if(score>=0){
                System.out.println("VERY_WEAK");
            }
        }
    }
}
