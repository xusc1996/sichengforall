package com.xsc.nanjing.HuaWeiMedium;

/**
 * Created by
 * Sicheng_XU
 * on 2021/3/29
 * 14:56
 * What hurts More...
 * The pain of hard work or the pain of regret?
 */
public class test4 {
    public static void main(String[] args) {
        int a = 1;
        int b = 1;
        double c = 1.0;
        double d = 2.0;
        //输出的时候不可以用逗号隔开
        System.out.printf("%.2f\n",c);
        System.out.printf("%.2f",d);

//        System.out.println(a+b);
    }
}
