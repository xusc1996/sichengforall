package com.xsc.nanjing.Service.Imlp;

import com.xsc.nanjing.Entity.CourseOrder;
import com.xsc.nanjing.Entity.PageResult;
import com.xsc.nanjing.Mapper.CourseOrderMapper;
import com.xsc.nanjing.Service.ICourseOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CourseOrderService implements ICourseOrderService {

    @Autowired
    CourseOrderMapper courseOrderMapper;

    @Override
    //实际上我们还仅仅只是在Mapper中把方法展开来，在service中只写一个外包的方法
    //利用layui进行分页查询，不需要插件
    //条件分类查询暂时还没写
    public PageResult<CourseOrder> findPageResult(CourseOrder condition, int page, int pageSize) {
        //findPageResult中又封装了来自mapper中的两个方法
        PageResult<CourseOrder> result = new PageResult<>();
        result.setCode(0);

        //我们要建立一个map来存储分页时的两个基本信息
        //这里的params是给后面mapper中的方法用的
        Map<String, Object> params = new HashMap<>();
        params.put("condition", condition);
        params.put("start", (page - 1) * pageSize);
        params.put("pageSize", pageSize);

        //开始装统一返回信息的第3个和第4个条件
            int total = courseOrderMapper.findCountByMap(params);
        result.setCount(total);
                                                  //实际上条件查询写在xml文件中的动态sql语句
        List<CourseOrder> list = courseOrderMapper.findOrderByMap(params);
        result.setData(list);

        return result;
    }

    @Override
    public void save(CourseOrder courseOrder) {
        //继续甩锅给mapper,save是提交按钮调用的，这里不需要返回值
        courseOrderMapper.insert(courseOrder);
    }

    @Override
    public CourseOrder findOrderById(String order_id) {
        return courseOrderMapper.findOrderById(order_id);
    }

    @Override
    public void update(CourseOrder courseOrder) {
        courseOrderMapper.updateOrderById(courseOrder);
    }

    @Override
    public void deleteOrderById(String order_id) {
        courseOrderMapper.deleteById(order_id);
    }
}
