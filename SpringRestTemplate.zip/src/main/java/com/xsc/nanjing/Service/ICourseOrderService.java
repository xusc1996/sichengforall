package com.xsc.nanjing.Service;

import com.xsc.nanjing.Entity.CourseOrder;
import com.xsc.nanjing.Entity.PageResult;

public interface ICourseOrderService {
    PageResult<CourseOrder> findPageResult(CourseOrder condition, int page, int limit);

    void save(CourseOrder courseOrder);

    CourseOrder findOrderById(String order_id);

    void update(CourseOrder courseOrder);

    void deleteOrderById(String order_id);
}
