package com.xsc.nanjing;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
//扫描包一定不要忘记，不然找不到bean
@ComponentScan(basePackages = {"com.xsc.nanjing"})
@MapperScan(basePackages = {"com.xsc.nanjing.mapper"})//扫描 Mapper
public class NanjingApplication {

    public static void main(String[] args) {
        SpringApplication.run(NanjingApplication.class, args);
    }

}
