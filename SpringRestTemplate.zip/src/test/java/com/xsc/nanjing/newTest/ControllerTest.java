package com.xsc.nanjing.newTest;

import com.xsc.nanjing.Entity.CURDResult;
import net.sf.json.JSONObject;
import com.mysql.cj.protocol.x.Notice;
import com.xsc.nanjing.Entity.CourseOrder;
import com.xsc.nanjing.NanjingApplication;
import org.junit.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

/**
 * Created by
 * Sicheng_XU
 * on 2021/3/30
 * 14:44
 * What hurts More...
 * The pain of hard work or the pain of regret?
 */

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,classes = NanjingApplication.class)
public class ControllerTest {
    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @BeforeAll
    static void init(){

    }
    @AfterAll
    static void end(){

    }

    @Test
    public void list(){

        CourseOrder courseOrder = InitCourseOrder();

        String url = "http://localhost:8888/courseOrder/list";
//        Notice
        RestTemplate restTemplate = new RestTemplate();
        String result = restTemplate.getForObject(url,String.class,courseOrder);
        System.out.println(result);

//        ResponseEntity<CURDResult> curdResult = this.restTemplate.postForEntity("http://localhost:"+port
//        +"/courseOrder/list",courseOrder,CURDResult.class);
//        System.out.println(curdResult.getStatusCode());
    }

    @Test
    public void testNoticeList(){
        RestTemplate restTemplate = new RestTemplate();
        Notice result = restTemplate.getForObject("http://localhost:8888/courseOrder/list",Notice.class);
        System.out.println(result);
    }


    private CourseOrder InitCourseOrder(){
        //这里直接这样写json格式就对了
        String objectString = "{result:1}";
        JSONObject jsonObject=JSONObject.fromObject(objectString);
        CourseOrder courseOrder = (CourseOrder) JSONObject.toBean(jsonObject, CourseOrder.class);
        return courseOrder;
    }


}
