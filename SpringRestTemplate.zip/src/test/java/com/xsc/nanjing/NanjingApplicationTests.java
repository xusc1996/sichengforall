package com.xsc.nanjing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NanjingApplicationTests {

    @Test
    void contextLoads() {
    }

}
