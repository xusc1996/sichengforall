package com.xsc.nanjing.Controller;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.xsc.nanjing.Entity.CourseOrder;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

/**
 * Created by
 * Sicheng_XU
 * on 2021/3/24
 * 10:26
 * What hurts More...
 * The pain of hard work or the pain of regret?
 */

//@RunWith(SpringJUnit4ClassRunner.class)
//这是老版本的导入
//@ContextConfiguration("classpath:com/xsc/nanjing/Mapper/CourseOrderMapper.xml")

@RunWith(SpringRunner.class)
@SpringBootTest
@WebAppConfiguration
public class CourseOrderControllerWebTest {

    //WebApplicationContext,是继承于ApplicationContext的一个接口，
    // 扩展了ApplicationContext，是专门为Web应用准备的，
    // 它允许从相对于Web根目录的路径中装载配置文件完成初始化
    @Autowired
    private WebApplicationContext webApplicationContext;

    private MockMvc mockMvc;

    @Before
    public void setup(){
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    @Test
    public void save() throws Exception {

        CourseOrder courseOrder = new CourseOrder();
        String requestJson = com.alibaba.fastjson.JSONObject.toJSONString(courseOrder);

        MockHttpServletRequestBuilder builder = MockMvcRequestBuilders
                .post("/courseOrder/save")//验证接口url
                .accept(MediaType.APPLICATION_JSON)//规定客户端接收数据的格式
                .contentType(MediaType.APPLICATION_JSON).content(requestJson);//规定向服务端发送数据的格式

        //看看是否返回正确的状态码
        MvcResult mvcResult = mockMvc.perform(builder)
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().is2xxSuccessful())
                .andReturn();

        //打印响应结果
        System.out.println(mvcResult.getResponse().getContentAsString());
    }
}
