package com.xsc.nanjing.Controller;

import com.xsc.nanjing.Entity.CourseOrder;
import com.xsc.nanjing.Entity.PageResult;

import com.xsc.nanjing.Service.Imlp.CourseOrderService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;


import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

import static org.mockito.Mockito.when;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;


/**
 * Created by
 * Sicheng_XU
 * on 2021/3/23
 * 10:42
 * What hurts More...
 * The pain of hard work or the pain of regret?
 */

@RunWith(MockitoJUnitRunner.class)
public class CourseOrderControllerTest {


    @Mock
    private CourseOrderService courseOrderService;

    @InjectMocks
    private CourseOrderController courseOrderController;


    @Test
    public void listJson(){
        //定义输入的假数据
        CourseOrder condition = new CourseOrder();

        //定义输出的假数据
        PageResult<CourseOrder>res = new PageResult<>();
        res.setCount(2021);

        //规定一下规则，打桩
        when(courseOrderService.findPageResult(condition, 3 ,26)).thenReturn(res);

        //真实方法调用
        PageResult<CourseOrder> result = courseOrderController.listJson(condition, 3, 26);

        //可以用断言检查一下
        assertThat(result.getCount(), equalTo(2021));
        //也可以直接输出
        System.out.println(result);
    }
}