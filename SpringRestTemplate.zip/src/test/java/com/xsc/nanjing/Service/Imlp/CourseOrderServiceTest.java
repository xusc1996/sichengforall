package com.xsc.nanjing.Service.Imlp;


import com.xsc.nanjing.Controller.CourseOrderController;
import com.xsc.nanjing.Entity.CourseOrder;
import com.xsc.nanjing.Entity.PageResult;
import com.xsc.nanjing.Mapper.CourseOrderMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;
import java.util.*;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
@Slf4j
public class CourseOrderServiceTest {

    @Mock  //导入Mapper
    private CourseOrderMapper courseOrderMapper;

    @InjectMocks
    private CourseOrderService courseOrderService;


    @Test
    //有返回值方法的测试
    public void findPageResult() {
        //设置虚假输入值
        Map<String, Object> params = new HashMap<>();
        CourseOrder condition = new CourseOrder();
        params.put("condition", condition);
        params.put("start", 0);
        params.put("pageSize", 0);

        //设置虚假返回值
        List<CourseOrder>list = new ArrayList<>();
        CourseOrder courseOrder1 = new CourseOrder();
        courseOrder1.setCourse_name("Mockito真好用");
        courseOrder1.setOrder_id("亚信科技");
        list.add(courseOrder1);

        when(courseOrderMapper.findCountByMap(params)).thenReturn(100);
        when(courseOrderMapper.findOrderByMap(params)).thenReturn(list);

        PageResult<CourseOrder> pageResult = courseOrderService.findPageResult(condition, 0, 0);

        System.out.println(pageResult);
    }

    @Test
    //没有返回值方法的测试
    public void update(){
        doNothing().when(courseOrderMapper).updateOrderById(isA(CourseOrder.class));
        //执行service层的方法
        courseOrderService.update(new CourseOrder());
        verify(courseOrderMapper,times(1)).updateOrderById(new CourseOrder());
    }
}